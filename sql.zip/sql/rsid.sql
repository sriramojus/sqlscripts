col sid format 9999
col username format a10
col osuser format a10
col program format a25
col process format 9999999
col spid format 999999
col logon_time format a13
col Action format a30

set lines 150

set heading off
set verify off
set feedback off

undefine inst_num
undefine sid_number
undefine spid_number
rem accept sid_number number prompt "pl_enter_sid:" 

col sid NEW_VALUE sid_number noprint 
col spid NEW_VALUE spid_number noprint

	 
	 select distinct s.sid   sid
--		,decode(count(*), 1,'null','No Session Found with this info') " " 
 	 FROM gv$session s
 	 WHERE s.sid LIKE NVL('&sid', '%')
--	 group by s.sid, p.spid;


col username form a20
col program form a60
col inst_id form 99 
col &sid_number form 99999

PROMPT  Inst_id     SID    Username               Program 
PROMPT ------------------------------------------------------

select inst_id, &sid_number,username,program from gv$session s
where sid = &sid_number 
order by 1;

PROMPT

rem accept inst_num number prompt "pl_enter_inst_id:" 
col inst_id noprint NEW_VALUE inst_num noprint

        select distinct s.inst_id inst_id
--                p.spid  spid
--              ,decode(count(*), 1,'null','No Session Found with this info') " "
         FROM gv$session s,
              gv$process p
         WHERE s.inst_id LIKE NVL('&inst_id','%')
         AND nvl(p.spid,'%') LIKE NVL ('&OS_ProcessID', '%')
         AND nvl(s.process,'%') LIKE NVL('&Client_Process', '%')
         AND s.paddr = p.addr
         AND s.inst_id = p.inst_id;
--       group by s.sid, p.spid;


PROMPT Session and Process Information
PROMPT -------------------------------

col event for a30
col module for a50

select '    INST_ID  	       		: '||v.inst_id 	|| chr(10)|| 
       '    SID  	       		: '||v.sid 	|| chr(10)|| 
       '    Serial Number		: '||v.serial# 	|| chr(10) ||
       '    Oracle User Name 		: '||v.username 	|| chr(10) ||
       '    Client OS user name		: '||v.osuser 	|| chr(10) ||
       '    Client Process ID	 	: '||v.process 	|| chr(10) ||
       '    Client machine Name 	: '||v.machine 	|| chr(10) ||
       '    Oracle PID 		 	: '||p.pid 	|| chr(10) ||
       '    OS Process ID(spid)	 	: '||p.spid 	|| chr(10) ||
       '    Session''s Status	  	: '||v.status 	|| chr(10) ||
       '    last call et(mins)          : '||round(v.last_call_et/60)   || chr(10) ||
       '    Logon Time		  	: '||to_char(v.logon_time, 'MM/DD HH24:MIpm')  	|| chr(10) ||
       --'    Program Name	 	: '||v.program 	|| chr(10) || 
       '    Program Name	 	: '||v.program 	|| chr(10) ||
       '    Module Name	 		: '||v.module 	|| chr(10) ||
       '    Action	 		: '||v.action 	|| chr(10) 
       --'    APPS User Name	 	: '||x.fnd_user_name 	|| chr(10) 
from gv$session v, gv$process p, gv$session x
where v.paddr = p.addr
and v.serial# > 1
and p.background is null
and p.username is not null
and v.sid=x.sid
and v.inst_id = x.inst_id
and p.inst_id = x.inst_id
and v.inst_id = &inst_num
and v.sid = &sid_number
order by v.logon_time, v.status, 1
/


PROMPT SQL_ID           HASH_VALUE   PREV_SQL_ID   PREV_HASH_VALUE
PROMPT -----------------------------------------------------------

select distinct s.sql_id sql_id,SQL_HASH_VALUE,PREV_SQL_ID,PREV_HASH_VALUE
from gv$sqltext , gv$session s
where gv$sqltext.address = s.sql_address
and gv$sqltext.inst_id = s.inst_id
and sid = &sid_number
and s.inst_id = &inst_num
/

PROMPT
PROMPT Sql Statement
PROMPT --------------

select sql_text
from gv$sqltext , gv$session
where gv$sqltext.address = gv$session.sql_address
and gv$sqltext.inst_id = gv$session.inst_id
and sid = &sid_number
and gv$session.inst_id = &inst_num
order by piece
/

PROMPT
PROMPT Event Wait Information
PROMPT ----------------------

select '   SID '|| &sid_number || ' on instance '|| &inst_num ||' is waiting on event	: ' || x.event || chr(10) ||
       '   P1 Text 		  	: ' || x.p1text || chr(10) ||
       '   P1 Value 		  	: ' || x.p1 || chr(10) ||
       '   P2 Text 		  	: ' || x.p2text || chr(10) ||
       '   P2 Value 		  	: ' || x.p2 || chr(10) ||
       '   P3 Text 		  	: ' || x.p3text || chr(10) ||
       '   P3 Value 		  	: ' || x.p3 
from gv$session_wait x
where x.sid= &sid_number
and   x.inst_id = &inst_num
-- added wait_time condition to prevent showing previous wait events
and x.wait_time=0
/

PROMPT
PROMPT Session Statistics
PROMPT ------------------

select        '     '|| b.name  ||'   		: '||decode(b.name, 'redo size', round(a.value/1024/1024,2)||' M', a.value) 
from gv$session s, gv$sesstat a, gv$statname b
where a.statistic# = b.statistic#
and name in ('redo size', 'parse count (total)', 'parse count (hard)', 'user commits')
and a.inst_id = b.inst_id
and s.inst_id = a.inst_id
and s.inst_id = b.inst_id
and a.inst_id = &inst_num
and s.sid = &sid_number
and a.sid = &sid_number
--order by b.name
order by decode(b.name, 'redo size', 1, 2), b.name
/

COLUMN USERNAME FORMAT a10
COLUMN status FORMAT a8
column RBS_NAME format a10


PROMPT
PROMPT Transaction and Rollback Information
PROMPT ------------------------------------

select        '    Rollback Used                : '||t.used_ublk*8192/1024/1024 ||' M' || chr(10) ||
              '    Rollback Records             : '||t.used_urec        || chr(10)||
              '    Rollback Segment Number      : '||t.xidusn           || chr(10)||
              '    Logical IOs                  : '||t.log_io           || chr(10)||
              '    Physical IOs                 : '||t.phy_io           || chr(10)||
              '    RBS Startng Extent ID        : '||t.start_uext       || chr(10)||
              '    Transaction Start Time       : '||t.start_time       || chr(10)||
              '    Transaction_Status           : '||t.status
FROM gv$transaction t, gv$session s
WHERE t.addr = s.taddr
and t.inst_id = s.inst_id
and s.sid = &sid_number
and s.inst_id = &inst_num
/

PROMPT
PROMPT Sort Information
PROMPT ---------------- 

column username format a20
column user format a20
column tablespace format a20

SELECT        '    Sort Space Used(8k block size is asssumed	: '||u.blocks/1024*8 ||' M'		|| chr(10) ||
              '    Sorting Tablespace 		  		: '||u.tablespace	|| chr(10)|| 
              '    Sort Tablespace Type		 	: '||u.contents	|| chr(10)|| 
              '    Total Extents Used for Sorting 		: '||u.extents	
FROM gv$session s, gv$sort_usage u
WHERE s.saddr = u.session_addr
AND s.inst_id = u.inst_id
AND s.sid = &sid_number
AND s.inst_id = &inst_num
/


set heading on
set verify on

clear column
exit;
