set linesize 300
set pagesize 300 verify off
col object_name   format a30
select  owner, object_name, object_type,status
from dba_objects
where object_name like upper('%&obj_name%')
order by owner,object_name;
exit;
