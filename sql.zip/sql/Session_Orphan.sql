set echo off verify off head on feed off pages 40 lines 200 trimspool on;
col username format a15
col machine format a18
col module for a30
col program for a50
col spid for 99999
col sid for 99999
col serial# for 99999
prompt
prompt Orphan spid's which don't have sessions in databae are :
prompt ========================================================
select inst_id,program from gv$process where program!= 'PSEUDO' and program not like 'oracle@%(P%)' 
and addr not in (select paddr from gv$session)  and addr not in (select paddr from gv$bgprocess) ;

set echo off verify off head on feed off pages 40 lines 200 trimspool on;
col username format a15
col machine format a18
col module for a30
col spid for 99999
col sid for 99999
col serial# for 99999
col process for 99999
prompt
prompt Orphan spid's which don't have client processes are :
prompt =====================================================
select p.spid,s.inst_id,s.sid,s.serial#,s.username,s.machine,s.sql_hash_value,s.module,s.process
from gv$session s,gv$process p
where s.paddr=p.addr
and   s.inst_id=p.inst_id
and s.process is null ;

exit;
