select 'DR is Lagging Behind '||round((sysdate-max(first_time))*24,2)||' Hours' from v$log_history;
exit;
