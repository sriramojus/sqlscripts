CLEAR  COL BREAK COMPUTE
SET    LINES 100 PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT


set feedback off serveroutput on

prompt
prompt Looking for transactions that are rolling back ...
prompt

declare
  cursor tx is
    select s.username,s.inst_id,s.sid,s.serial#, t.xidusn, t.xidslot, t.xidsqn, 
    t.used_ublk,to_char(s.logon_time,'DD-MON-YY HH24:MI') as logonTime,t.used_ublk*8192/1024/1024 "RbsUsed(MB)"
    from gv$transaction t,gv$session s
    where t.used_ublk > 1 and s.saddr = t.ses_addr and s.inst_id=t.inst_id;

  user_name  varchar2(30);
  s_sid  number;
  s_serial# number;
  s_instid number;
  s_logontime varchar2(30);
  t_rbsused_mb number;
  xid_usn    number;
  xid_slot   number;
  xid_sqn    number;
  used_ublk1 number;
  used_ublk2 number;
  
begin
  open tx;

  loop
    fetch tx into user_name,s_instid,s_sid,s_serial#,xid_usn, xid_slot, xid_sqn, used_ublk1,s_logontime,t_rbsused_mb;
    exit when tx%notfound;

    if tx%rowcount = 1
    then
      dbms_lock.sleep(10);
    end if;

    select sum(used_ublk) into used_ublk2
    from sys.v_$transaction
    where xidusn  = xid_usn and
      xidslot = xid_slot and
      xidsqn  = xid_sqn;
    

    if used_ublk2 < used_ublk1
    then
      sys.dbms_output.put_line( '    INST_ID                                  : '||s_instid);      
      sys.dbms_output.put_line( '    SID                                      : '||s_sid);         
      sys.dbms_output.put_line( '    Serial Number                            : '||s_serial#);    
      sys.dbms_output.put_line( '    Oracle User Name                         : '||user_name);   
      sys.dbms_output.put_line( '    Logon time                               : '||s_logontime);
      sys.dbms_output.put_line( '    UNDO Used(MB)                            : '||t_rbsused_mb);
      sys.dbms_output.put_line( '    Approx.Time to complete Rollback         : '||to_char(sysdate + used_ublk2 / (used_ublk1 - used_ublk2) / 6 /
60 / 24,'HH24:MI:SS DD-MON-YYYY'));

    end if;
  end loop;
  if user_name is null
  then
    sys.dbms_output.put_line('No transactions appear to be rolling back.');
  end if;
end;   
/

prompt
prompt Looking for transactions that are being rolled back by SMON ...
prompt
alter session set NLS_DATE_FORMAT='DD-MON-YYYY HH24:MI:SS'; 
set feed on
select inst_id,usn, state, undoblockstotal "Total", undoblocksdone "Done", undoblockstotal-undoblocksdone "ToDo", 
decode(cputime,0,'unknown',sysdate+(((undoblockstotal-undoblocksdone) / (undoblocksdone / cputime)) / 86400))
"Estimated time to complete" 
from gv$fast_start_transactions where state<>'RECOVERED';

SET    PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT
exit;
