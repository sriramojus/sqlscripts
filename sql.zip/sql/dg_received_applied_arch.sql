prompt D_check_log_sequence_received_sofar.sql
set linesize 200
select thread#,
       max(sequence#) as "Max_SEQ_Received_soFar"
from v$archived_log
where archived = 'YES'
and RESETLOGS_TIME=(select max(RESETLOGS_TIME) from v$archived_log)
group by thread#
/

prompt  D_check_last_log_sequence_applied using archived_log table
select thread#,max(sequence#) as "Max_SEQ_Applied_sofar"
from v$archived_log
where applied='YES'
and RESETLOGS_TIME=(select max(RESETLOGS_TIME) from v$archived_log)
group by thread#
/

prompt "Other way to monitor last_log_sequence_applied log_history table

select thread#,max(sequence#) as "Max_SEQ_Applied_sofar"
from v$log_history
where RESETLOGS_TIME=(select max(RESETLOGS_TIME) from v$archived_log)
group by thread#
/

exit;
