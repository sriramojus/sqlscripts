column sample_end format a21

select to_char(min(s.end_interval_time),'DD-MON-YYYY DY HH24:MI') sample_end
,q.sql_id
,q.plan_hash_value
,sum(q.EXECUTIONS_DELTA) executions
,sum(q.PARSE_CALLS_DELTA) hard_parse
,sum(q.VERSION_COUNT) Version
,sum(q.INVALIDATIONS_DELTA) Invalidation
,sum(q.ROWS_PROCESSED_DELTA)/greatest(nvl(sum(executions_delta),0)) as rows_per_exec
,round(sum(DISK_READS_delta)/greatest(nvl(sum(executions_delta),0))) Diskio_per_exec
,round(sum(BUFFER_GETS_delta)/greatest(nvl(sum(executions_delta),0))) bufferio_per_exec
,round((sum(ELAPSED_TIME_delta)/greatest(nvl(sum(executions_delta),0))/1000)) msec_exec
from dba_hist_sqlstat q, dba_hist_snapshot s
where q.SQL_ID=trim('&sqlid')
and s.snap_id = q.snap_id
and s.dbid = q.dbid
and s.instance_number = q.instance_number
and substr(to_char(s.end_interval_time,'DD-MON-YYYY DY HH24:MI'),13,2) like '%&hr24_filter.%'
-- and s.begin_interval_time between  sysdate - &hours/24 and sysdate
and s.end_interval_time >= to_date(trim('&start_time.'),'dd-mon-yyyy hh24:mi')
and s.begin_interval_time <= to_date(trim('&end_time.'),'dd-mon-yyyy hh24:mi')
group by s.snap_id
, q.sql_id
, q.plan_hash_value
order by s.snap_id, q.sql_id, q.plan_hash_value
/
exit;
