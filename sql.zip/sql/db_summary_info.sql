SET LINESIZE 200
COL HOST_NAME FOR A25
Col STARTUP_TIME FOR A30
col STARTUP_TIME FOR A30
select INSTANCE_NAME, HOST_NAME, VERSION, LOGINS,STATUS,
       to_char(STARTUP_TIME,'DD-MON-YYYY DAY HH24:MI:SS') "STARTUP_TIME" 
FROM gv$instance
;

select round((a.data_size+b.temp_size+c.redo_size)/1024/1024/1024) "Total DB Size(GB)"
from ( select nvl(sum(bytes),0) data_size
from dba_data_files ) a,
( select nvl(sum(bytes),0) temp_size
from dba_temp_files ) b,
( select nvl(sum(bytes),0) redo_size
from sys.v_$log ) c
/

SET LINESIZE 145
SET PAGESIZE 9999
SET VERIFY   off

COLUMN tablespace_name       FORMAT a18               HEAD 'Tablespace Name'
COLUMN tablespace_status     FORMAT a9                HEAD 'Status'
COLUMN tablespace_size       FORMAT 999,999,999,999   HEAD 'Size in MB'
COLUMN used                  FORMAT 999,999,999,999   HEAD 'Used in MB'
COLUMN used_pct              FORMAT 999               HEAD 'Pct. Used'
COLUMN current_users         FORMAT 9,999             HEAD 'Current Users'

BREAK ON report
COMPUTE SUM OF tablespace_size  ON report
COMPUTE SUM OF used             ON report
COMPUTE SUM OF current_users    ON report

SELECT
    d.tablespace_name                      tablespace_name
  , d.status                               tablespace_status
  , NVL(a.bytes/1024/1024, 0)              tablespace_size
  , NVL(t.bytes/1024/1024, 0)              used
  , TRUNC(NVL(t.bytes / a.bytes * 100, 0)) used_pct
  , NVL(s.current_users, 0)                current_users
FROM
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes) bytes
      from dba_temp_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes_used) bytes
      from v$temp_extent_pool
      group by tablespace_name
    ) t
  , v$sort_segment  s
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = t.tablespace_name(+)
  AND d.tablespace_name = s.tablespace_name(+)
  AND d.extent_management like 'LOCAL'
  AND d.contents like 'TEMPORARY'
/

SELECT   A.tablespace_name tablespace, D.mb_total,
            SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used,
            D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_free
   FROM     v$sort_segment A,
             (
           SELECT   B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
             FROM     v$tablespace B, v$tempfile C
            WHERE    B.ts#= C.ts#
            GROUP BY B.name, C.block_size
            ) D
   WHERE    A.tablespace_name = D.name
  GROUP by A.tablespace_name, D.mb_total;

/*************************************
---- Get DB Block size
*************************************/
/************************************
-- Undo Free Space on DBA_FREE_SPACE
************************************/
set lines 200
-- set pages 80
clear break
clear compute
ttitle center 'Space Usage on Tablespaces' skip 1
center '*****************************************' skip 2
spool check_free_space
column TABLESPACE_NAME format a20
select a.TABLESPACE_NAME,
       round(a.bytes_used/(1024*1024),2) TOTAL_SPACE_IN_MB,
       round(b.bytes_free/(1024*1024),2) FREE_SPACE_IN_MB,
       round(((a.bytes_used-b.bytes_free)/a.bytes_used)*100,2) percent_used
  from
  (
  select TABLESPACE_NAME, sum(bytes) bytes_used
    from dba_data_files
   group by TABLESPACE_NAME
  ) a,
  (
  select TABLESPACE_NAME, sum(BYTES) bytes_free, min(BYTES) smallest, max(BYTES) largest
    from dba_free_space
   group by TABLESPACE_NAME
  ) b
 where a.TABLESPACE_NAME=b.TABLESPACE_NAME(+)
     and a.TABLESPACE_NAME like '%UNDO%'
    order by b.BYTES_free desc;

/*********************************
-- Undo Space used based on Status
************************************/

show parameter db_block_size;
/*********************************
-- Undo Space used based on Status
************************************/
set linesize 200
column tablespace_name format a50 wrap
column status format a30 wrap


compute sum of "Total Space in GB" on report
select tablespace_name, status,sum(blocks) "Total Blocks",
      (sum(blocks) * 8192 )/1024/1024/1024 "Total Space in GB"
from dba_undo_extents
group by tablespace_name, status
order by 1;

select status,
  round(sum_bytes / (1024*1024), 0) as MB,
  round((sum_bytes / undo_size) * 100, 0) as PERC
from
(
  select status, sum(bytes) sum_bytes
  from dba_undo_extents
  group by status
),
(
  select sum(a.bytes) undo_size
  from dba_tablespaces c
    join v$tablespace b on b.name = c.tablespace_name
    join v$datafile a on a.ts# = b.ts#
  where c.contents = 'UNDO'
    and c.status = 'ONLINE'
);

column name format a50
set pages 20
select name,to_number(value)/1024/1024 "Size(MB)",instance_name
from gv$parameter,gv$instance
where name in ('sga_target','sga_max_size','shared_pool_size','db_cache_size','large_pool_size','memory_max_target','memory_target','log_buffer')
and gv$parameter.inst_id=gv$instance.inst_id
order by 1,3;

column value format a40
select name,value,instance_name
from gv$parameter,gv$instance
where name in ('db_cache_advice','pga_aggregate_target','workarea_size_policy','undo_tablespace','undo_retention','undo_management','log_checkpoint_interval','log_checkpoint_timeout')
and gv$parameter.inst_id=gv$instance.inst_id
order by 1,3;



set linesize 200
column member format a50 wrap
column min_checkpoint_change# format 9999999999999999
column first_change# format 999999999999999
alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS'; 
select LF.member, L.group#, L.thread#, L.sequence#, L.status, 
       L.first_change#, L.first_time,L.NEXT_CHANGE#,L.NEXT_TIME
from v$log L, v$logfile LF
where LF.group# = L.group# 
/

exit;
