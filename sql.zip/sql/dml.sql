set linesize 120
set pagesize 50 verify off
column name format a20
column owner format a10
column type format a20


undefine sid

select /*+ rule */ session_id, 
       owner,
       name, 
       mode_held,
       mode_requested,
       blocking_others
from dba_dml_locks
where upper(name) like '&objectname' 
/

exit;
