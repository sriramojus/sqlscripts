set lines 132 pages 999
column LOCAL_TRAN_ID format a14;
column GLOBAL_TRAN_ID format a14;
column STATE format a12;
column MIXED format a5;
column ADVICE format a5;
column TRAN_COMMENT format a5;
column FAIL_TIME format a9;
column OS_TERMINAL format a11;
column HOST  format a14;
column OS_USER format a14;

select LOCAL_TRAN_ID, OS_USER, STATE, MIXED, ADVICE, TRAN_COMMENT,
       to_char(FAIL_TIME, 'DD-MM-YYYY HH:MI:SS'), FORCE_TIME, OS_TERMINAL,  HOST
from dba_2pc_pending;

exit;
