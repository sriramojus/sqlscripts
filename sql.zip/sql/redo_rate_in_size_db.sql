set linesize 200 verify off pages 1000 feed off
prompt
accept days char prompt 'How many days(Default - 1 day) :'
prompt
select
      /*+parallel(a,8) parallel(b,8)*/
      to_char(completion_time,'DD-MON-YYYY') DAY ,
      ROUND( SUM( blocks * block_size ) / 1024 / 1024 / 1024 ) "Archive Size in GB"
from
        v$archived_log a,gv$instance b
where
        a.thread#=b.inst_id
        and   standby_dest='NO'
        and   trunc(completion_time)>sysdate-nvl('&days',1)
        and   completion_time >= to_date( to_char(completion_time,'DD-MON-YYYY'),'DD/MM/YYYY')
group by
        to_char(completion_time,'DD-MON-YYYY')  order by 1;
prompt
exit;
