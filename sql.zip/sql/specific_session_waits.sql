--------------------------------------------------------------------------------
-- SCCS INFO : ses_waited.sql [1.12] 06/25/02 23:49:55
-- FILE INFO : ses_waited.sql
-- CREATED   : ckarthik
-- DATE      : 07/02/2000
-- DESC      : Displays Sess info with SQL-TEXT.
--------------------------------------------------------------------------------
CLEAR  COL BREAK COMPUTE
SET    PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF

COL sid      FORMAT 9999
COL event    FORMAT A32
COL totwait  FORMAT 99999999
COL timout   FORMAT 9999
COL waited_m FORMAT 9999
COL avgwt_m  FORMAT 9999
COL maxwt    FORMAT 999999
COL typ      NOPRINT

BREAK   ON sid on typ SKIP 2
COMPUTE SUM OF waited_m ON typ
COMPUTE SUM OF totwait ON typ

SELECT sid, event, ROUND(time_waited/100/60) waited_m,
       ROUND(average_wait/100/60) avgwt_m, total_waits totwait,
       total_timeouts timout, max_wait maxwt,
       DECODE(event, 'pipe get'                                 , 'I',
                     'Null event'                               , 'I',
                     'pmon timer'                               , 'I',
                     'smon timer'                               , 'I',
                     'slave wait'                               , 'I',
                     'client message'                           , 'I',
                     'virtual circuit'                          , 'I',
                     'dispatcher timer'                         , 'I',
                     'PL/SQL lock timer'                        , 'I',
                     'rdbms ipc message'                        , 'I',
                     'WMON goes to sleep'                       , 'I',
                     'parallel dequeue wait'                    , 'I',
                     'virtual circuit status'                   , 'I',
                     'SQL*Net message from client'              , 'I',
                     'parallel query dequeue wait'              , 'I',
                     'parallel query idle wait - Slaves'        , 'I',
                     'KXFX: execution message dequeue - Slaves' , 'I',
                     'KXFX: Reply Message Dequeue - Query Coord', 'I', 'D') typ
FROM   v$session_event
WHERE  sid = NVL('&sid_______','0')
ORDER  BY 8,1,3 
/

SET    PAGES 32 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT
exit;
