--------------------------------------------------------------------------------
-- SCCS INFO : ses_sql.sql [1.3] 06/25/02 23:49:53
-- FILE INFO : ses_sql.sql
-- CREATED   : ckarthik
-- DATE      : 07/02/2000
-- DESC      : Displays Sess info with SQL-TEXT.
--------------------------------------------------------------------------------
CLEAR  COL BREAK COMPUTE
SET    PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF

SELECT 
	'Sharable Mem(K):'||sharable_mem/1024 ||chr(10)||
	'Persistent Mem(K):'||persistent_mem/1024 ||chr(10)||
        'Runtime Mem(K):'||runtime_mem/1024 ||chr(10)||
	'Sorts:'||sorts||chr(10)||
	'Loaded Versions:'||loaded_versions||chr(10)||
        'Open Versions:'||open_versions||chr(10)||
	'Users Opening:'||users_opening||chr(10)||
	'Executions:'||executions||chr(10)||
       	'Users Executing:'||users_executing||chr(10)||
	'Optimizer Mode:'||optimizer_mode||chr(10)||
	'Optimizer Cost:'||optimizer_cost||chr(10)||
       	'First Load Time:'||first_load_time||chr(10)||
	'Loads:'||loads||chr(10)||
	'Invalidations:'||invalidations||chr(10)||
	'Parse Calls:'||parse_calls||chr(10)||
       	'Disk Reads:'||disk_reads||chr(10)||
	'Buffer Gets:'||buffer_gets||chr(10)||
	'Rows Processes:'||rows_processed||chr(10)||
       	'SQL Text:'||sql_text  "Detail"
FROM   v$sql WHERE (address, hash_value) = 
	(SELECT sql_address, sql_hash_value
                                            FROM   v$session
                                            WHERE  sid = '&sid_4_sql' )
/

SET    PAGES 32 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT

exit;
