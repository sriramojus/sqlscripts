-- SCCS INFO : ses_jdbc.sql [1.5] 04/20/03 13:09:18
-- FILE INFO : ses_jdbc.sql
-- CREATED   : ckarthik
-- DATE      : 07/02/2000
-- DESC      : Displays Sess info with SQL-TEXT.
----------------------------------------------------------------------------------------------------
prompt " JDBC Session counts details by machine wise "
prompt " ******************************************** "

CLEAR  COL BREAK COMPUTE
SET    SERVEROUT ON LINES 200 VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT

COLUMN who      FORMAT A50
COLUMN How_Many FORMAT 999,999

SELECT inst_id,RPAD(machine||' : '||osuser||' : '||username||' : '||status,50,'.') who ,
       count(*) How_Many
FROM   gv$session
WHERE  program || module like ('%JDBC Thin Client%')
AND SUBSTR(status,1,1) LIKE UPPER(NVL('&status_I_A_','%'))
GROUP  BY inst_id,machine, osuser, username, status
ORDER  BY 3 desc
/

prompt
prompt
accept space prompt "Please press enter for continue ................"
prompt
prompt
prompt "Global JDBC Sessions Details "
prompt " *******************************"

set linesize 200
column sid format 9999999999999
column serial# format 999999999
column spid format a10 heading "Database|Process"
column unix_process format a7 heading "Client|Process"
column user_name format a15 trunc heading "FNDUSER|NAME"
column machine format a20 heading "Client|Machine"
column username format a20 heading "Database|Username"

select s.inst_id,s.sid,s.serial#,p.spid,s.process unix_process,s.machine,s.username,s.status
from gv$process p,gv$session s
where p.addr = s.paddr 
-- AND   upper(s.program) like 'JDBC%'
AND s.program || s.module like ('%JDBC Thin Client%')
AND SUBSTR(s.status,1,1) LIKE UPPER(NVL('&status_I_A_','%'))
AND s.inst_id LIKE NVL('&inst_id', '%')
order by 8 desc
/

exit;
