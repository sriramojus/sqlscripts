prompt  "Monitor exclusive lock based on Resource name :"
prompt "Description: This will be useful during analyze times to fine Library cache lock holder details across all RAC Nodes."
prompt "BLOCKED 	NUMBER	1 if this lock request is blocked by others, otherwise 0"
prompt " BLOCKER	NUMBER	1 if this lock is blocking others, otherwise 0"
prompt " Library cache locks are globalized as global locks in the range of [LA][LZ]"
prompt " Library cache pins are also globalized as lock types in the range [NA]-[NZ]"
prompt " Request/Grant Modes: EX - Exclusive; PR - Protected Read; NL - Null"
prompt 
prompt "*******************************************************************************"
prompt "              Global Blocker Session Details                                   "
prompt "*******************************************************************************"

set lines 200
SET PAGESIZE 1000
set trimout on
col state format a12
col resource_name1 format a30 wrap
col resource_name2 format a20 wrap
col program format a14 wrap
col machine format a14 wrap
col event format a15 wrap
col BLOCKER format 9999 wrap
col BLOCKED format 9999 wrap
col inst_id format 9999 wrap
col sid format 99999 wrap
col last_call_et format 9999999 wrap
column blocker heading 'BLOC|KER'
column blocked heading 'BLOC|KED'
column inst_id heading 'IN|ST'
column request_level heading 'REQUEST|LEVEL'
column grant_level heading 'GRANT|LEVEL'
column last_call_et heading 'LAST|CALL|ET (MI)'

select /* parallel(gbe,8) */ gbe.resource_name1,gbe.resource_name2,gbe.inst_id ,s.sid,s.serial#,gbe.pid "SPID",gbe.blocker,gbe.blocked,
      s.status, s.program,s.machine,s.sql_id,s.event,round(s.last_call_et/60) "LAST_CALL_ET",
      gbe.grant_level,gbe.request_level
from gv$ges_blocking_enqueue gbe,gv$session s, gv$process p
where gbe.blocker=1 and
gbe.inst_id=s.inst_id and
gbe.inst_id=p.inst_id and
p.inst_id=s.inst_id and
gbe.pid=p.spid and
p.addr=s.paddr
order by gbe.resource_name1,gbe.resource_name2,gbe.blocker desc;

prompt "*******************************************************************************"
prompt "              Global Blocker and Waiter Session Details                        "
prompt "*******************************************************************************"
BREAK ON resource_name1 ON resource_name2 SKIP 4

select /* parallel(gbe,8) */ gbe.resource_name1,gbe.resource_name2,gbe.inst_id ,s.sid,s.serial#,gbe.pid "SPID",gbe.blocker,gbe.blocked,
      s.status, s.program,s.machine,s.sql_id,s.event,round(s.last_call_et/60) "LAST_CALL_ET",
      gbe.grant_level,gbe.request_level
from gv$ges_blocking_enqueue gbe,gv$session s, gv$process p
where gbe.inst_id=s.inst_id and
gbe.inst_id=p.inst_id and
p.inst_id=s.inst_id and
gbe.pid=p.spid and
p.addr=s.paddr
order by gbe.resource_name1,gbe.resource_name2,gbe.blocker desc;

exit;
