SET LINESIZE 200 pages 1000
SET VERIFY off feed off

col value noprint NEW_VALUE blksz noprint

select distinct value from gv$parameter where name='db_block_size';

prompt "*****************************************************************************"
prompt "      TEMP USAGE  BY SID                                "
prompt "*****************************************************************************"

accept sid_num number prompt 'ENTER the SID or press enter for SIDs:'
prompt sid_num=&sid_num

col INST_ID for 99
col SID for 99999
col SPID for a6
col username for a20
col osuser for a15
col machine for a20
col MODULE for a25 trunc
col event for a27
col program for a30 trunc
col logon_time form a21

select
s.inst_id	inst_id
  , s.sid	 sid
  , s.serial#	serial#
  , p.spid	 SPID
  , s.username	username
  , s.osuser	osuser
  , s.STATUS    STATUS
  , s.MODULE    MODULE
  , s.MACHINE   MACHINE
  , s.SQL_ID    SQL_ID
  , to_char(s.LOGON_TIME, 'DD-MON-YYYY HH24:MI:SS') LOGON_TIME
  , round(s.LAST_CALL_ET/60) Idle_min
  , t.temp_mb	TEMP_MB
from
gv$session s, gv$process p,
(select distinct /*+ RULE */ s.inst_id inst_id,s.sid sid,s.serial# serial#,sum(round((u.blocks*&blksz)/1024)) temp_mb
FROM    gv$session s, gv$tempseg_usage u
WHERE   s.saddr    = u.session_addr
AND     u.contents = 'TEMPORARY'
AND     s.sid = decode(&sid_num,0,s.sid,&sid_num)
group by s.inst_id,s.sid,s.serial#) t
where
s.inst_id = p.inst_id
and s.paddr = p.addr
and s.inst_id = t.inst_id
and s.sid = t.sid
and p.inst_id = t.inst_id
order by 7 
/
