rem *********************************************************** 
rem
rem	File: db_cache_hist.sql 
rem	Description: DB cache advise shown as a histogram 
rem   
rem	From 'Oracle Performance Survival Guide' by Guy Harrison
rem		Chapter 18 Page 548
rem		ISBN: 978-0137011957
rem		See www.guyharrison.net for further information
rem  
rem		This work is in the public domain NSA 
rem   
rem
rem ********************************************************* 

set pagesize 1000
set lines 100
column name format a22
column description format a40
column display_value format a6 heading "Value"
set echo on

SELECT inst_id,name, display_value, description
FROM gv$parameter
WHERE name IN
            ('sga_target','sga_max_size',
             'memory_target',
             'memory_max_target',
             'pga_aggregate_target',
             'shared_pool_size',
             'large_pool_size',
             'java_pool_size')
      OR name LIKE 'db%cache_size'
and inst_id like nvl('&inst_id','%')
ORDER BY inst_id,name
/

set pages 100
set lines 200
set echo on
column size_mb format 99,999 heading "Size|MB"
column estd_physical_reads format 999,999,999 heading "Est Phys|Reads"
column estd_factor_pct format 9,999.99 heading "Relative|Phy Rds"
column histogram format a60

SELECT inst_id,size_for_estimate size_mb,
       ROUND(estd_physical_read_factor * 100, 2) estd_factor_pct,
       RPAD(' ',
       ROUND(estd_physical_reads / MAX(estd_physical_reads) OVER () * 60),
       DECODE(size_factor, 1, '-', '*'))
          histogram
FROM gv$db_cache_advice
WHERE name = 'DEFAULT' and block_size='8192' 
and inst_id like nvl('&inst_id','%')
ORDER BY 1,2 DESC
/

exit;
