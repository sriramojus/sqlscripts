/************************************
Note : 146599.1 Note : 62143.1
************************************/
set echo off verify off
set lines 132
set pages 100
col name for a40
col stmt for a60 word wrapped
col SQL_Stmt for a60 word wrapped
col value for a15
PROMPT Shared Pool related parameters
PROMPT ==============================

select nam.ksppinm name, val.KSPPSTVL value
  from x$ksppi nam, x$ksppsv val
 where nam.indx = val.indx
   and nam.ksppinm like '%shared%'
 order by 1;

PROMPT If the ratio of misses to executions is more than 1%, then try to reduce the library cache misses by increasing the shared pool size
PROMPT ====================================================================================================================================

SELECT SUM(PINS) "EXECUTIONS", SUM(RELOADS) "CACHE MISSES WHILE EXECUTING" ,
       sum(reloads)/sum(pins) miss_percentage
  FROM V$LIBRARYCACHE;

PROMPT Finding Literal SQLs
PROMPT ====================

SELECT substr(sql_text,1,40) "SQL_Stmt", count(*) , sum(executions) "TotExecs"
  FROM v$sqlarea
 WHERE executions < 5
 GROUP BY substr(sql_text,1,40)
 HAVING count(*) > 30
 ORDER BY 2
  ;

PROMPT Finding SQLs which uses lot of shared pool memory
PROMPT =================================================

SELECT substr(sql_text,1,40) "Stmt", count(*), sum(sharable_mem)    "Mem", sum(users_opening)   "Open", sum(executions)      "Exec"
  FROM v$sql
 GROUP BY substr(sql_text,1,40)
HAVING sum(sharable_mem) > (select value*0.01 from v$parameter where name='shared_pool_size')
;

-- where MEMSIZE is about 10% of the shared pool size in bytes


/*
-- High version counts can occur in various Oracle8i releases due to problems with progression monitoring.
-- This can be disabled by setting _SQLEXEC_PROGRESSION_COST to '0' as described earlier in this note

SELECT address, hash_value, version_count , users_opening , users_executing, substr(sql_text,1,40) "SQL"
  FROM v$sqlarea
 WHERE version_count > 10
;
*/

PROMPT Allocations causing shared pool memory to be aged out
PROMPT =====================================================

SELECT *
  FROM x$ksmlru
 WHERE ksmlrnum>0
;

-- The X$KSMLRU table shows which memory allocations have caused the MOST memory chunks
-- to be thrown out of the shared pool since it was last queried.
-- This is sometimes useful to help identify sessions or statements which are continually causing space to be requested.
-- If a system is well behaved and uses well shared SQL, but occasionally slows down this select can help identify the cause.


PROMPT Free (unused) memory in the SGA
PROMPT ===============================

col name for a30
col pool for a20
select pool , name, bytes/1024/1204 space_in_MB
  from v$sgastat
 where name = 'free memory';

exit;
