set linesize 150
set pages 99

prompt "********************************************************************************************"
prompt "SELECT * FROM table(dbms_xplan.display_awr(nvl('sql_id',null),nvl('plan_hash_value',null),null));"
prompt "plan_hash_value is optional and you should press <Enter> for null"
prompt "********************************************************************************************"

SELECT * FROM table(dbms_xplan.display_awr(nvl('&sql_id',null),nvl('&plan_hash_value',null),null));
exit;
