set lines 200 pages 100 verify off
column file_name format a50
column tablespace_name format a32
accept tbs_name char prompt 'Enter Tablespace Name : '
accept file_name char prompt 'Enter File Name : '
select 
	ddf.tablespace_name,
	df.file#,	
	creation_time,
	file_name,
	ddf.bytes/1024/1024 "Size (MB)"
from 
	dba_data_files ddf, 
	v$datafile df
where 
	ddf.file_id=df.file#
	and tablespace_name=upper(nvl('&tbs_name', tablespace_name))
	and file_name=nvl('&file_name', file_name)
order by 1,3;
exit
