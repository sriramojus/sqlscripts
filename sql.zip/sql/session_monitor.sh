#!/bin/bash
SPOOLFILE1=/tmp/session_mon_$(hostname)_$$.lst
if [ "SUCCESS" = 'Y' ]; then
rm -f $SPOOLFILE1
else 
echo -e "[WARN]: Please check the session on `hostname`"
exit
fi
sqlplus -s "/as sysdba"<<EOF
col sid for 999999
col serial# for 9999999
col event for a25
col osuser for a15
col sql_hash_value for 99999999999999
col sql_text for a100
set lines 200
spool $SPOOLFILE1
select a.sid,a.serial#,a.status,a.event,a.sql_id,a.osuser,a.sql_hash_value,b.sql_text  from v$session a,v$sql b where a.osuser='obiadmin' and a.status<>'INACTIVE' and b.sql_id=a.sql_id;
spool off
exit
EOF
if [ -s $SPOOLFILE1 ] & [ "cat $SPOOLFILE|grep -i "no rows selected"|wc -l" -eq "0" ]; then
echo -e "[INFO]: Please find the running session"
echo $SPOOLFILE1
else 
echo -e "[WARN}: Please validate the sessions from OSUSR: OBIADMIN"
fi

