set linesize 120 verify off
set pagesize 100

accept job_number char prompt 'Enter Job Number[Default - All Jobs] : '

SELECT /*+ rule */ sid, r.job, log_user, r.this_date, r.this_sec
FROM dba_jobs_running r, dba_jobs j
WHERE r.job = j.job
and r.job like '%&job_number%'
;
exit
