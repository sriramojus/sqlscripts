set lines 200 pages 100 verify off
select COMPONENT_TYPE,COMPONENT_NAME,COMPONENT_STATUS from apps.fnd_svc_components where startup_mode='AUTOMATIC' order by 1,2;
exit;
