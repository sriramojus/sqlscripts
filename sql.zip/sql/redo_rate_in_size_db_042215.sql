set linesize 200 verify off pages 100
accept days char prompt 'How many days(Default - 1 day) :'
select to_char(bit,'DD-MON-YYYY') DAY,round(sum(avgredoinmb)/1024,2) "Avg Redo in GB"
from
(
select 
	/*+parallel(a,8) parallel(b,8)*/ 
	b.begin_interval_time bit,
	b.instance_number inst,
	(AVERAGE*60*(ROUND( TO_NUMBER ( CAST(b.end_interval_time as DATE) - CAST(b.begin_interval_time as DATE)) * 24 * 60 )))/1024/1024 AvgRedoInMB
from 
	DBA_HIST_SYSMETRIC_SUMMARY a,
	dba_hist_snapshot b 
where 
	a.snap_id=b.snap_id 
	and 
	b.instance_number=a.instance_number
	and 
	a.metric_name='Redo Generated Per Sec'
	and 
	trunc(b.begin_interval_time)>sysdate-nvl('&days',1)
)
group by to_char(bit,'DD-MON-YYYY')
ORDER BY TO_DATE (DAY, 'DD/MM/YYYY');
exit;
