set lines 100 pages 100
select to_char(creation_time,'MON-YY') MONYY, round(sum(bytes)/1024/1024/1024,0) "Growth in GB"
from v$datafile
group by to_char(creation_time,'MON-YY')
order by TO_DATE (MONYY, 'MON-YY');
exit;
