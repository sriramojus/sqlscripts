col OWNER for a15; 
col TABLE_NAME for a30; 
col TABLESPACE_NAME for a20; 
set lines 200; 
set pages 999; 
  

select owner, table_name,tablespace_name,blocks, num_rows, avg_row_len, 
next_extent 
, round((blocks * 8192)/(1024 * 1024),1) table_size 
, round((num_rows * avg_row_len)/(1024 * 1024),1) mbytes_used 
, round((blocks * 8192)/(1024 * 1024) - (num_rows * avg_row_len)/(1024 * 
1024),1) mbytes_free 
from dba_tables 
where owner not in ('SYSTEM','SYS') 
and table_name not in (select table_name from dba_tab_columns where 
data_type in ('LONG','LONG RAW','CLOB','BLOB','NCLOB','RAW','BFILE')) 
and blocks > 0 
and (blocks * 8192)/(1024 * 1024) - (num_rows * avg_row_len)/(1024 * 
1024) > 1000 
order by tablespace_name,mbytes_free;
exit;
