--------------------------------------------------------------------------------
-- SCCS INFO : ddl.sql [1.6] 09/13/02 18:40:41
-- FILE INFO : tbl_nolog.sql
-- CREATED   : ckarthik
-- DATE      : 07/02/2000
-- DESC      : Displays Sess info with SQL-TEXT.
--------------------------------------------------------------------------------

CLEAR  COL BREAK COMPUTE
SET    PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF

COL object_name FORMAT A35
COL type        FORMAT A20
COL sid         FORMAT 9999
COL held        FORMAT A5
COL request     FORMAT A7

SELECT session_id sid,
       owner||'.'||name object_name,
       type,
       mode_held held,
       mode_requested request
FROM   dba_ddl_locks
WHERE  name LIKE UPPER('%&object_name%')
/

SET    PAGES 32 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT
exit;
