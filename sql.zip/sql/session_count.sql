set pages 100 verify off
accept username char prompt 'Enter Oracle Username : '
select username, status, count(*)
  from v$session
 where username = decode ('&username',null,username,'&username')
 group by username, status;
exit;
