set linesize 200 
col name  format a40 heading 'Parameter' 
col value format a36 heading 'Value'
set feedback off
set verify off
set pages 200
Prompt ###############################
Prompt CURSOR related INIT Parameters
Prompt ###############################
select /* rule */ inst_id, name, value from gv$parameter where lower(name) like '%open%cursor%' order by  1; 

col sid format 9999
col username format a15
col osuser format a10
col module format a25
col process format 9999999
col machine format a20
set lines 150
Prompt ##################################################
Prompt Top Sessions having 75% of total OPEN_CURSOR count
Prompt ##################################################
select distinct /* rule */  s.inst_id,s.username, s.sid, s.serial#, s.machine,s.osuser,s.module,a.value "Opened Cursor Count" 
from gv$sesstat a, gv$statname b, gv$session s where s.inst_id='&&INST_ID' and a.statistic# = b.statistic#  and s.sid=a.sid 
and b.name = 'opened cursors current' and a.value > ( select (value*0.10) from gv$parameter where lower(name) like '%open%cursor%' and inst_id='&&INST_ID')
order by a.value desc;

Prompt ##################################################
prompt Top 10 Total cursors open by username and machine
Prompt ##################################################
col username format a20
col machine format a20
select rownum ,a.* 
from ( 
select sum(a.value) total_cur, avg(a.value) avg_cur, max(a.value) max_cur, 
s.username, s.machine 
from gv$sesstat a, gv$statname b, gv$session s 
where a.statistic# = b.statistic#  and s.sid=a.sid 
and b.name = 'opened cursors current' 
and s.inst_id=&inst_id 
group by s.username, s.machine 
order by 1 desc) a 
where rownum < 11;

prompt What is in the session cursor cache along with query
prompt
column user_name format a30 wrap 
column sql_text format a100 wrap 
set pages 1000
select distinct c.user_name, count(*), c.sql_id
from gv$open_cursor c
where c.sid=&sid
and c.inst_id=&inst_id
group by c.user_name,c.sql_id
order by 2 desc
/
exit;
