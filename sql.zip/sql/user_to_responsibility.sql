set lines 300 pages 100 verify off feed off
col user_name format a15
col RESPONSIBILITY_NAME format a40
col DESCRIPTION format a50
col ROLE_NAME format a30

accept username char prompt 'Enter User Name(Default - NONE) :'
PROMPT
PROMPT RESPONSIBILITY INFORMATION
PROMPT
SELECT  distinct u.user_id,
                  u.user_name,
         wur.ROLE_ORIG_SYSTEM_ID responsibility_id,
         r.responsibility_name RESPONSIBILITY_NAME,
         wur.effective_start_date START_DATE,
         wur.effective_end_date  END_DATE,
	u.USER_GUID,
         r.description DESCRIPTION
  FROM   apps.wf_local_user_roles wur, applsys.fnd_responsibility_tl r, applsys.fnd_user u
  WHERE  wur.user_name = u.user_name
      and wur.role_orig_system = 'FND_RESP'
      and wur.partition_id = 2
      and wur.assignment_type='D'
      and r.language = 'US'
      and wur.ROLE_ORIG_SYSTEM_ID = r.responsibility_id
      and u.user_name=nvl(upper('&username'),'NONE');

PROMPT
PROMPT ROLE INFORMATION
PROMPT
SELECT  distinct u.user_id,
                  wur.user_name,
                 wur.role_name,
                 wur.role_orig_system,
                 wur.partition_id,
                 wur.assignment_type,
         wur.effective_start_date START_DATE,
         wur.effective_end_date  END_DATE,
         wur.ASSIGNMENT_REASON DESCRIPTION
  FROM   apps.wf_local_user_roles wur, applsys.fnd_responsibility_tl r, applsys.fnd_user u
  WHERE  wur.user_name = u.user_name
  and wur.role_orig_system = 'UMX'
  and wur.partition_id = 13
  and wur.assignment_type='D'
  and wur.ROLE_ORIG_SYSTEM_ID = r.responsibility_id(+)
  and u.user_name=nvl(upper('&username'),'NONE');
exit;
