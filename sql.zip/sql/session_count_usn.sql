set pages 100 verify off
accept username char prompt 'Enter Oracle Username : '
select inst_id,username, status, count(*)
  from gv$session
 where username = decode ('&username',null,username,'&username')
 group by inst_id,username, status
 order by 1,2,3;
exit;
