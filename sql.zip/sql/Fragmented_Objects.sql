set lines 200 pages 100 feed off verify off
accept frag_pct char prompt 'Enter Fragmentation Percent(Default - 30) :'
select owner,table_name,tablespace_name,blocks, num_rows, avg_row_len,next_extent,table_size,mbytes_used,mbytes_free,round(mbytes_free/table_size*100,2) fragpct from
(
select owner, table_name,tablespace_name,blocks, num_rows, avg_row_len,
next_extent
, round((blocks * 8192)/(1024 * 1024),1) table_size
, round((num_rows * avg_row_len)/(1024 * 1024),1) mbytes_used
, round((blocks * 8192)/(1024 * 1024) - (num_rows * avg_row_len)/(1024 *
1024),1) mbytes_free
from dba_tables
where owner not in ('SYSTEM','SYS')
and table_name not in (select table_name from dba_tab_columns where
data_type in ('LONG','LONG RAW','CLOB','BLOB','NCLOB','RAW','BFILE'))
and blocks > 0
and (blocks * 8192)/(1024 * 1024) - (num_rows * avg_row_len)/(1024 *
1024) > 1000)
where
        table_size<>0
        and
        round(mbytes_free/table_size*100,2) > nvl('&frag_pct',30)
order by fragpct;

exit;
