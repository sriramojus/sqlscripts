set echo off verify off head on feed off pages 40 lines 200 trimspool on;
col username format a15
col machine format a18
col module for a30
col spid for 99999
col sid for 99999
col serial# for 99999
prompt
prompt Killed status session details are :
prompt ===================================
select s.inst_id,p.spid,s.sid,s.serial#,s.username,s.machine,s.sql_hash_value,s.module
from gv$session s,gv$process p
where s.paddr=p.addr and
s.status='KILLED'; 

exit;
