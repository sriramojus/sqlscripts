set linesize 200 verify off pages 100
col "Owner:Table:Partition" format a80
accept days char prompt 'How many days(Default - 1 day) :'
accept howmany char prompt 'How many Objects(Default - 10) :'

select 
	object_details "Owner:Table:Partition",objgrth "Object Growth in MB"
from
(
	select 
		owner||':'||OBJECT_NAME||':'||nvl(SUBOBJECT_NAME,'NONE') object_details ,
		sum(DELETED_IN_MB)+sum(ADDED_IN_MB) objgrth 
	from 
		dbsnmp.object_growth_details 
	where 
		(owner,object_name) not in (select table_owner,table_name from sys.dba_tab_modifications where truncated='YES') 
		and trunc(COLLECTED_ON)>trunc(sysdate-nvl('&days',8)) 
	group by owner||':'||OBJECT_NAME||':'||nvl(SUBOBJECT_NAME,'NONE') 
	order by 2 desc
) where rownum<nvl('&howmany',10);
exit;
