set verify off lines 200 pages 2000
col NAME format a40
col SESSION_VALUE format a20
col SYSTEM_VALUE format a20
col SYSTEM_DEFAULT format a20
select a.ksppinm NAME, b.ksppstvl SESSION_VALUE,
c.ksppstvl SYSTEM_VALUE, c.KSPPSTDF SYSTEM_DEFAULT
from x$ksppi a, x$ksppcv b, x$ksppsv c
where a.indx = b.indx and a.indx = c.indx
and a.ksppinm like nvl('%&parameter%',a.ksppinm)
;
exit;
