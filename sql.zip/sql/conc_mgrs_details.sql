set lines 300 pages 300
col user_concurrent_queue_name format a40
col target_node format a17
col "Primary/Failover Node" format a40
col status format a10
select
          c.user_concurrent_queue_name
        , nvl(r.runprocs, 0) "RP"
        , a.max_processes "MP"
        , a.CONTROL_CODE
        , a.TARGET_NODE "Running Node"
        , a.NODE_NAME||'/'||a.NODE_NAME2 "Primary/Failover Node"
        , case when nvl(r.runprocs, 0) != a.max_processes then 'CHECK FROM FE'  else decode(b.meaning,'Activated','Active',b.meaning) end "Status"
        , nvl(d.cnt,0) "Running Count"
        , nvl(e.cnt,0) "Pending Count"
from
          apps.fnd_concurrent_queues a
        , apps.fnd_lookups b
        , apps.fnd_concurrent_queues_tl c
        , (select
                        q.user_concurrent_queue_name cmname,count(*) cnt
                from
                          apps.fnd_concurrent_queues_tl q
                        , apps.fnd_concurrent_processes cp
                        , apps.fnd_concurrent_requests r
                where
                            cp.CONCURRENT_PROCESS_ID = r.controlling_manager
                        and cp.QUEUE_APPLICATION_ID = q.application_id
                        and cp.CONCURRENT_QUEUE_ID = q.CONCURRENT_QUEUE_ID
                        and r.phase_code='R'
                        and q.language=USERENV('LANG')
                group by
                        q.user_concurrent_queue_name
          ) d
        , (select
                          b.user_concurrent_queue_name cmname
                        , decode(status_code,'I','Pending Normal','Unknown') sts
                        , count(*) cnt
                from
                          apps.fnd_concurrent_worker_requests a
                        , applsys.fnd_concurrent_queues_tl b
                where
                            a.concurrent_queue_id=b.concurrent_queue_id
                        and phase_code='P'
                        and status_code='I' and hold_flag != 'Y'
                        and a.requested_start_date<=sysdate and b.language=USERENV('LANG')
                group  by
                        b.user_concurrent_queue_name,status_code
          ) e
        ,(SELECT
                          q.user_concurrent_queue_name cmname
                        , count(1) runprocs
                FROM
                          gv$process p
                        , gv$session s
                        , apps.fnd_concurrent_processes f
                        , apps.fnd_concurrent_queues_vl q
                WHERE
                            p.addr = s.paddr
                        and p.inst_id = s.inst_id
                        and s.audsid = f.session_id
                        and f.concurrent_queue_id = q.concurrent_queue_id
                        and f.queue_application_id = q.application_id
                        and q.manager_type = f.manager_type
                group by
                        q.user_concurrent_queue_name
         ) r
where
            a.enabled_flag='Y'
        and nvl(a.CONTROL_CODE,'Active') not in ('E')
        and b.lookup_type='CP_CONTROL_CODE'
        and nvl(a.control_code,'B')=b.lookup_code
        and a.concurrent_queue_id=c.concurrent_queue_id
        and d.cmname(+)=c.user_concurrent_queue_name
        and e.cmname(+)=c.user_concurrent_queue_name
        and r.cmname(+)=c.user_concurrent_queue_name
        and node_name in (select node_name from apps.fnd_nodes where support_cp='Y')
        and upper(c.user_concurrent_queue_name) like upper(nvl('%&user_concurrent_queue_name%',c.user_concurrent_queue_name))
        and c.language=USERENV('LANG')
order by
        1
;
exit;
