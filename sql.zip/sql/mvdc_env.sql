set linesize 200
set pages 99
set heading off
set verify off
col value for a90
col name for a50

select inst_id,name,value 
from gv$parameter 
where name in ('db_unique_name','service_names','db_domain','spfile','fal_client','fal_server','log_archive_dest_1','log_archive_dest_2','log_archive_dest_3','log_archive_dest_4','log_archive_dest_state_1','log_archive_dest_state_2','log_archive_dest_state_3','log_archive_dest_state_4','log_archive_config','standby_archive_dest','db_recovery_file_dest','db_flashback_retention_target','db_recovery_file_dest_size','local_listener','remote_listener','dg_broker_config_file1','dg_broker_config_file2','dg_broker_start','standby_file_management')
order by 2
/
prompt " DB UNIQUE NAME Register in Database "
select DB_UNIQUE_NAME from V$DATAGUARD_CONFIG;

prompt " Check where MRP process is running "

select inst_id, process,status,client_process,thread#,sequence#,delay_mins
from  gv$managed_standby
where process like 'MRP%';

exit;
