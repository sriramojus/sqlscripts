SET LINESIZE 200 pages 1000
SET VERIFY off feed off 


COLUMN tablespace_name       FORMAT a15               HEAD 'Tablespace Name'
COLUMN username              FORMAT a15               HEAD 'Username'
COLUMN osuser                FORMAT a15               HEAD 'osuser'
COLUMN sid                   FORMAT 99999             HEAD 'SID'
COLUMN inst_id               FORMAT 99                HEAD 'INST_ID'
COLUMN serial_id             FORMAT 99999999          HEAD 'Serial#'
COLUMN contents              FORMAT a9                HEAD 'Contents'
COLUMN extents               FORMAT 999,9999999       HEAD 'Extents'
COLUMN blocks                FORMAT 999,9999999       HEAD 'Blocks'
COLUMN Mbytes                FORMAT 999,999,999       HEAD 'MBytes'
COLUMN segtype               FORMAT a12               HEAD 'Segment Type'
COLUMN sql_text              FORMAT A50               HEAD 'SQLTEXT'
COLUMN module                FORMAT A50
COLUMN program               FORMAT A10
BREAK ON tablespace_name ON report
COMPUTE SUM OF Mbytes     ON report

prompt "*****************************************************************************"
prompt "      TEMP USAGE INFO " 
prompt "*****************************************************************************"

col value noprint NEW_VALUE blksz noprint

select distinct value from gv$parameter where name='db_block_size';

accept inst_num number prompt 'ENTER the value of inst_id or press enter for full DB:' 
accept size char prompt 'Enter Usage in MB per session (Default : 1000MB): '

SELECT a.*
from (
SELECT
    a.inst_id       inst_id
  , a.sid 			sid
  , a.username      username
  , a.osuser 		osuser
  , b.tablespace    tablespace_name
  , b.segtype       segtype
  , a.module        module
  ,to_char(a.logon_time,'MM/DD/YYYY HH24:MI:SS') logon_time
  , (b.blocks * &blksz)/(1024*1024) Mbytes
FROM
    gv$session     a
  , gv$tempseg_usage  b
  , gv$parameter      c
WHERE a.saddr = b.session_addr
and   a.inst_id = b.inst_id
and   a.inst_id = c.inst_id
and   b.inst_id=c.inst_id
and   c.name   ='db_block_size'
and   a.inst_id = decode(&inst_num, 0,a.inst_id,&inst_num )
and  (b.blocks * &blksz)/1024/1024 > decode('&size',null,1000,'&&size')
order by 1,9 asc) a
/

prompt******************************************************************************
prompt "NOTE: Above information is based on the no of cursors open in each session"
prompt "      That's the reason you may see multiple rows for each SID" 
prompt******************************************************************************

SET LINESIZE 145
SET PAGESIZE 9999
SET VERIFY   off
 
COLUMN tablespace_name       FORMAT a18               HEAD 'Tablespace Name'
COLUMN tablespace_status     FORMAT a9                HEAD 'Status'
COLUMN tablespace_size       FORMAT 999,999,999,999   HEAD 'Size in MB'
COLUMN total_allocated	     FORMAT 999,999,999,999   HEAD 'Allocated in MB'
COLUMN used                  FORMAT 999,999,999,999   HEAD 'Used in MB'
COLUMN Free		     FORMAT 999,999,999,999   HEAD 'Free in MB'
COLUMN used_pct              FORMAT 999               HEAD 'Pct. Used'
COLUMN current_users         FORMAT 9,999             HEAD 'Current Users'
 
BREAK ON report
COMPUTE SUM OF tablespace_size  ON report
COMPUTE SUM OF total_allocated  ON report
COMPUTE SUM OF used             ON report
COMPUTE SUM OF Free 		ON report
COMPUTE SUM OF current_users    ON report

set feed off

prompt
prompt " ********************************************************************************************"
prompt " TEMP TABLESPACE INFO "
prompt " **********************************************************************************************"

 
SELECT
    d.tablespace_name                       tablespace_name
  , d.status                                tablespace_status
  , NVL(a.bytes/1024/1024, 0)               tablespace_size
  , NVL(t.total_allocated, 0)               total_allocated
  , NVL(t.bytes/1024/1024, 0)               used
  , (a.bytes/1024/1024)-(t.bytes/1024/1024) Free
  , TRUNC(NVL(t.bytes / a.bytes * 100, 0))  used_pct
  , NVL(s.current_users, 0)                 current_users
FROM
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes) bytes
      from dba_temp_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes_used) bytes,sum(extents_cached) Total_allocated
      from gv$temp_extent_pool
      group by tablespace_name
    ) t
  , v$sort_segment  s 
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = t.tablespace_name(+)
  AND d.tablespace_name = s.tablespace_name(+)
  AND d.extent_management like 'LOCAL'
  AND d.contents like 'TEMPORARY'
/
 

 
prompt
prompt " ********************************************************************************************"
prompt " GLOBAL TEMP USAGE INSTANCES LEVEL "
prompt " **********************************************************************************************"
 
SELECT   A.inst_id,A.tablespace_name tablespace, D.mb_total, E.Allocated,
SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used,
D.mb_total - nvl(sum(f.bytes_used)/1024/1024,0) mb_free
FROM     gv$sort_segment A,
(
SELECT   B.INST_ID,B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
FROM     gv$tablespace B, gv$tempfile C
WHERE    B.ts#= C.ts#
and c.inst_id=b.inst_id
GROUP BY B.INST_ID,B.name, C.block_size
) D,
(
select inst_id, tablespace_name,sum(extents_cached) Allocated
from gv$temp_extent_pool 
group by inst_id,tablespace_name order by 1
) E,
(
select tablespace_name,
 sum(bytes_used) bytes_used
--NVL(sum(bytes_used)/1024/1024, 0) bytes_used 
from gv$temp_extent_pool
group by tablespace_name
order by tablespace_name
) F
WHERE   
A.tablespace_name = D.name
and A.inst_id=D.inst_id
and A.tablespace_name = E.tablespace_name
and A.tablespace_name = F.tablespace_name
and A.inst_id=E.inst_id
and D.inst_id=E.inst_id
--and A.inst_id=F.inst_id
--and E.inst_id=F.inst_id
--and D.inst_id=F.inst_id
GROUP by a.inst_id,A.tablespace_name, D.mb_total,E.Allocated
order by a.tablespace_name 
/

set feed off serveroutput on
set autoprint on head off flush off feedback off verify off echo off 
col username form a25
prompt
accept userInput char prompt 'Would like to check temp usage by DB username[Y/N]:'

prompt
prompt*****************************************************************************
prompt"          Total TEMP space used by DB user at the Database level 
prompt*****************************************************************************
prompt
prompt USERNAME                        MBYTES  
prompt ------------------------------------------------

variable x refcursor

BEGIN
        IF trim(upper('&userInput')) = 'Y' then
               open :x for SELECT
  				   a.username      username
  				  , sum((b.blocks * c.value)/(1024*1024)) Mbytes
			    FROM
    				    gv$session     a
  				  , gv$tempseg_usage  b
                                  , gv$parameter c
			    WHERE a.saddr = b.session_addr
			    AND   a.inst_id = b.inst_id
                            AND   a.inst_id = c.inst_id
                            AND   b.inst_id = c.inst_id
                            AND   c.name = 'db_block_size'
			    GROUP BY a.username
			    ORDER BY 2; 
       ELSE
             open :x for select 'EXITING....' from dual; 
       END IF; 
END;
/

exit;
