set lines 300 pages 200 verify off
col action_time format a30
col comments format a30
select * from sys.registry$history where upper(comments) like '%PSU%' or upper(action)='CPU';
exit;
