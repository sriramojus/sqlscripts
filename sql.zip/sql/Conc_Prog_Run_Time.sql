set linesize  200 pages 80 verify off
col Time(min) format a13
col user_concurrent_program_name format a50
accept user_concurrent_prgm_name char prompt 'Enter User Concurrent Program Name: '
alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS';
PROMPT
PROMPT Concurrent Program Run Time History
PROMPT
select  request_id,
	user_concurrent_program_name,
	decode (phase_code,'R', 'RUNNING', 
			   'P', 'PENDING', 
			   'I', 'INACTIVE',
			   'C', 'Completed',
			    phase_code) phase_code,
	decode (status_code,'A', 'WAITING', 
			    'B', 'RESUMING', 
			    'C', 'NORMAL', 
			    'D', 'CANCELLED', 
			    'E', 'ERROR',
			    'F', 'SCHEDULED',
			    'G', 'WARNING',
			    'H', 'ON HOLD',
			    'I', 'NORMAL',
			    'M', 'NO MANAGER',
			    'Q', 'STANDBY', 
			    'S', 'SUSPENDED', 
			    'T', 'TERMINATE', 
			    'X', 'TERMINATED',
		            'Z', 'WAITING',
			    'R', 'NORMAL',
			    'U', 'DISABLED',
			    'W', 'PAUSED',
			    status_code) status_code,
	actual_start_date,
	actual_completion_date,
	decode(actual_completion_date, null, 'Not Completed', round((actual_completion_date-actual_start_date)*24*60,2) ) "Time(min)"
from    apps.fnd_concurrent_requests cr, apps.fnd_concurrent_programs_tl cp
where   cr.concurrent_program_id = cp.concurrent_program_id
and     upper(cp.user_concurrent_program_name) like upper('%&user_concurrent_prgm_name%')
and cp.language=USERENV('LANG')
order by user_concurrent_program_name, to_number(request_id)
;
col Program format a80
col "Minumum Run Time ( Minutes)" format 99,999.99
col "Maximum Run Time ( Minutes)" format 99,999.99
col "Avg Run Time ( Minutes )" format 99,999.99
PROMPT 
PROMPT Concurrent Program Min/Max/Avg Runtime
PROMPT
select pn.user_concurrent_program_name Program,round(min(fcr.actual_completion_date - fcr.actual_start_date )*1440,2) "Minumum Run Time ( Minutes) ", round(max(fcr.actual_completion_date - fcr.actual_start_date )*1440,2) "Maximum Run Time ( Minutes) ", round(avg(fcr.actual_completion_date - fcr.actual_start_date )*1440,2) "Avg Run Time ( Minutes )"
from apps.fnd_concurrent_requests fcr,apps.fnd_user fu,apps.fnd_concurrent_programs_vl pn
where upper(pn.user_concurrent_program_name) like upper('%&user_concurrent_prgm_name%')
and phase_code='C' and status_code='C'
and fcr.requested_by=fu.user_id
and  fcr.program_application_id = pn.application_id
and   fcr.concurrent_program_id  = pn.concurrent_program_id
group by user_concurrent_program_name; 
exit;

