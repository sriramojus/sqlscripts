set pagesize 1000
set lines 100
column name format a22
column description format a40
column display_value format a6 heading "Value"
set echo on

SELECT inst_id,name, display_value, description
FROM gv$parameter
WHERE name IN
            ('sga_target','sga_max_size',
             'memory_target',
             'memory_max_target',
             'pga_aggregate_target',
             'shared_pool_size',
             'large_pool_size',
             'java_pool_size')
      OR name LIKE 'db%cache_size'
and   inst_id like nvl('&inst_id','%')
ORDER BY inst_id,name
/


set linesize 200
set pages 100
set feedback off

SELECT distinct to_char(b.end_interval_time, 'dd-Mon-yyyy hh24:mi') end,a.SGA_SIZE "Size of SGA in MB",
       a.sga_size_factor "Size Factor",
       a.estd_db_time "Est DB in sec",
       a.ESTD_PHYSICAL_READS "Est Phy Reads"
FROM dba_hist_sga_target_advice a,dba_hist_snapshot b
where a.snap_id=b.snap_id
and a.instance_number like nvl('&inst_id','%')
and end_interval_time > SYSDATE - &daysold
order by 1 ;

exit;
