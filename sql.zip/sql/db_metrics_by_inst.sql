set linesize 200 verify off pages 100
accept days char prompt 'How many days(Default - 1 day) :'
accept instno char prompt 'Enter instance number(Default - All ) :'

select 
	to_char(bit,'DD-MON-YYYY') DAY,
	inst,
	round((avg(ARPS))*6/1024/1024,2) "Avg Redo Per Sec-MB",
	round(avg(ATPS)*6,2) "Avg TPS",
	round(avg(RIOPS)*6,2) "Read IOPS",
	round(avg(WIOPS)*6,2) "Write IOPS",
	round((avg(RBPS))*6/1024/1024,2) "Avg Read MBPS",
	round((avg(WBPS))*6/1024/1024,2) "Avg Write MBPS",
        round((avg(MRPS))*6*count(distinct inst)/1024/1024,2) "Max Redo Per Sec-MB",
        round(avg(MTPS)*6*count(distinct inst),2) "Max TPS",
        round(avg(MRIOPS)*6*count(distinct inst),2) "Max Read IOPS",
        round(avg(MWIOPS)*6*count(distinct inst),2) "Max Write IOPS",
        round((avg(MRBPS))*6*count(distinct inst)/1024/1024,2) "Max Read MBPS",
        round((avg(MWBPS))*6*count(distinct inst)/1024/1024,2) "Max Write MBPS"
from
(
select 
	/*+parallel(a,8) parallel(b,8)*/ 
	b.begin_interval_time bit,
	b.instance_number inst,
	decode(a.metric_name,'Redo Generated Per Sec',a.average,0) ARPS,
	decode(a.metric_name,'User Transaction Per Sec',a.average,0) ATPS,
	decode(a.metric_name,'Physical Read Total IO Requests Per Sec',a.average,0) RIOPS,
	decode(a.metric_name,'Physical Write Total IO Requests Per Sec',a.average,0) WIOPS,
	decode(a.metric_name,'Physical Read Total Bytes Per Sec',a.average,0) RBPS,
	decode(a.metric_name,'Physical Write Total Bytes Per Sec',a.average,0) WBPS,
        decode(a.metric_name,'Redo Generated Per Sec',a.maxval,0) MRPS,
        decode(a.metric_name,'User Transaction Per Sec',a.maxval,0) MTPS,
        decode(a.metric_name,'Physical Read Total IO Requests Per Sec',a.maxval,0) MRIOPS,
        decode(a.metric_name,'Physical Write Total IO Requests Per Sec',a.maxval,0) MWIOPS,
        decode(a.metric_name,'Physical Read Total Bytes Per Sec',a.maxval,0) MRBPS,
        decode(a.metric_name,'Physical Write Total Bytes Per Sec',a.maxval,0) MWBPS
from 
	DBA_HIST_SYSMETRIC_SUMMARY a,
	dba_hist_snapshot b 
where 
	a.snap_id=b.snap_id 
	and 
	b.instance_number=a.instance_number
	and 
	a.metric_name in ('Redo Generated Per Sec','User Transaction Per Sec','Physical Read Total IO Requests Per Sec','Physical Write Total IO Requests Per Sec','Physical Read Total Bytes Per Sec','Physical Write Total Bytes Per Sec')
	and 
	trunc(b.begin_interval_time)>sysdate-nvl('&days',1)
	and
	b.instance_number=nvl('&instno',b.instance_number)
)
group by inst,to_char(bit,'DD-MON-YYYY')
ORDER BY TO_DATE (DAY, 'DD/MM/YYYY'),inst;
exit;
