set echo off
set linesize 200
set pages 100

column executions      heading "Execs"      format 99999999
column rows_processed  heading "Rows Procd" format a20
column loads           heading "Loads"      format 999999.99
column buffer_gets     heading "Buffer Gets"
column sql_text        heading "SQL Text"   format a60 wrap
column avg_cost        heading "Avg Cost"   format 9999999999999999
column event           heading "Wait|Event" format a20 wrap

break on report
compute sum      of rows_processed     on report
compute sum      of executions         on report
compute sum  avg of loads              on report
compute avg      of avg_cost           on report


PROMPT 
PROMPT Top 20 most expensive SQL based on average cost  ...
PROMPT

select rownum as rank, a.*
from (
   select gv$sqlarea.inst_id,gv$sqlarea.sql_id,buffer_gets, lpad(rows_processed ||
       decode(users_opening + users_executing, 0, ' ','*'),20) "rows_processed",
       executions, loads,
       (decode(rows_processed,0,1,1)) *
            buffer_gets/ decode(rows_processed,0,1,
                                  rows_processed) avg_cost,gv$session.event,
      sql_text
   from  gv$sqlarea,gv$session
   where gv$sqlarea.hash_value = hash_value and gv$sqlarea.inst_id=gv$session.inst_id
   and   gv$sqlarea.sql_id=gv$session.sql_id
   and   gv$session.inst_id LIKE NVL('&inst_id','%')
   order by 7 desc) a
where rownum < 21
/  		 

exit;    
