col EVENT_NAME for a55
set lines 200 pages 100
 select /*+parallel(wfd,8)*/ wfd.user_data.EVENT_NAME EVENT_NAME,
decode(wfd.state,
0, '0 = Ready',
1, '1 = Delayed',
2, '2 = Retained',
3, '3 = Exception',
to_char(substr(wfd.state,1,12))) State,
count(*) COUNT
from applsys.wf_deferred wfd
group by wfd.user_data.EVENT_NAME, wfd.state
order by 3 desc, 1 asc
;

col corrid for a25
SELECT wfdtm.corrid,
DECODE(wfdtm.state,
0, '0 = Ready',
1, '1 = Delayed',
2, '2 = Retained',
3, '3 = Exception',
TO_CHAR(SUBSTR(wfdtm.state,1,12))) State,count(1)
FROM apps.wf_deferred_table_m wfdtm
group by wfdtm.corrid,wfdtm.state
order by 1,2
;
exit;
