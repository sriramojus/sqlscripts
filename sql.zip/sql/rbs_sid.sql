set linesize 200
set pages 99
set verify off
Prompt
Prompt Global Undo Tablespace Details
Prompt #######################
Prompt 
col Undo_Retention format a10
select a.tablespace_name,nvl(a.tot,0) "Total Size in GB",
       nvl(round(b.active,2),0) "Used/Active in GB", 
       nvl(round((b.active*100/a.tot),2),0) percent_used,
       nvl(d.unexpired,0) "Unexpired in GB",nvl(c.expired,0) "Expired in GB",f.undo_ret Undo_Retention
from
(select tablespace_name, round(sum(bytes)/(1024*1024*1024),2) tot
  from dba_data_files where tablespace_name in (select value from gv$parameter where name='undo_tablespace')
 group by tablespace_name) a,
(select tablespace_name,round(sum(bytes)/1024/1024/1024,2) active from dba_undo_extents where status='ACTIVE' group by tablespace_name) b,
(select tablespace_name,round(sum(bytes)/1024/1024/1024,2) expired from dba_undo_extents where status='EXPIRED' group by tablespace_name) c,
(select tablespace_name,round(sum(bytes)/1024/1024/1024,2) unexpired from dba_undo_extents where status='UNEXPIRED' group by tablespace_name) d,
(select tablespace_name,ltrim(round(sum(bytes)/1024/1024)) free  from dba_data_files 
  where tablespace_name in (select value from gv$parameter where name='undo_tablespace')
 group by tablespace_name) e,
(select y.value tablespace_name,x.value undo_ret from
(select inst_id,value from gv$parameter where name='undo_retention') x,
(select inst_id,value from gv$parameter where name='undo_tablespace') y
where x.inst_id=y.inst_id) f
where a.tablespace_name=b.tablespace_name(+)
and a.tablespace_name=c.tablespace_name(+)
and a.tablespace_name=d.tablespace_name(+)
and a.tablespace_name=e.tablespace_name(+)
and a.tablespace_name=f.tablespace_name(+)
order by 1
;

set linesize 200
column tablespace_name format a20 
COLUMN USERNAME FORMAT a10
COLUMN status FORMAT a8
set pages 99
set echo off
set verify off
TTITLE 'Total MB  used by a user in a rbs'
prompt "**********************************************************"
SELECT r.tablespace_name,s.username,s.inst_id,s.sid,s.serial#,s.sql_id,
       nvl(round(t.used_ublk*8192/1024/1024),0) as  "RbsUsed(MB)", 
       t.used_urec, 
       t.log_io, 
       t.phy_io, 
       t.start_time,
       t.status
FROM gv$transaction t, gv$session s,dba_rollback_segs r
WHERE t.addr = s.taddr 
and r.segment_id = t.xidusn
and t.inst_id=s.inst_id
and t.used_ublk*8192/1024/1024 > nvl('&undo_in_mb',0)
and s.inst_id = (NVL('&inst_id________',s.inst_id))   
order by s.inst_id,t.used_urec desc 
;

exit;
