set linesize 200
set pages 99

accept sid_no number prompt 'Please Enter SID : '
accept instancenumber number prompt 'Please Enter INST_ID : '


column user_name format a20 wrap
column module format a30 wrap
column action format a30 wrap
column machine format a30 wrap
column user_form_name format a30 wrap
column description format a30 wrap

select s_login.user_name,s_login.user_form_name ,s_login.description ,
       s_all.module,s_all.action,s_all.machine,s_all.process,s_all.status,to_char(s_all.logon_time,'DD-MON-YYYY HH24:MI:SS')           
from   gv$session s_all,
( 
 select u.user_name,
 s.module,
 s.action,
 s.paddr,
 l.login_id,
 a.user_form_name,
 u.description
 from   apps.fnd_user u,
 apps.fnd_logins l,
 apps.fnd_login_responsibilities r,
 apps.fnd_signon_audit_view a,
 gv$session s
 where  s.audsid = r.audsid
 and    r.end_time is null
 and    r.login_id = l.login_id
 and    l.user_id = u.user_id
 and    s.action is not null
 and    a.user_id=u.user_id
) s_login
where  s_login.paddr (+) = s_all.paddr and 
sid=&sid_no
and inst_id=&instancenumber;
exit;
