set linesize 200

column name format a50

prompt " init parameter values "
prompt "**************************************"
column MB heading "Alloc|(MB)"

select inst_id,name,to_number(value)/1024/1024 as MB
from gv$parameter
where name in ('sga_target','sga_max_size','shared_pool_size','shared_pool_reserved_size','db_cache_size','large_pool_size','db_keep_cache_size','java_pool_size')
and   inst_id like nvl('&inst_id','%')
order by 2,1;



col component format a20 
col oper_type format a10
col initial_mb format 99,999
col target_mb format 99,999
col end_time format a25 heading "End|Time"
set pagesize 99


SELECT inst_id,to_char(end_time,'DD-MON-YY HH24:MI') end_time,
       component, oper_type, 
       initial_size / 1048576 initial_mb,
       target_size / 1048576 target_mb
FROM gv$memory_resize_ops
WHERE end_time > SYSDATE - &daysold
and   inst_id like nvl('&inst_id','%')
ORDER BY inst_id,end_time DESC; 
prompt
prompt
accept space prompt "Press Enter for continue ..................."
prompt
prompt
prompt "sga Dynamic component"

ALTER SESSION SET nls_date_format = 'DD/MM/YYYY HH:MI:SS'; 

SET PAGESIZE 99 
SET LINESIZE 255 
COL COMPONENT FORMAT A25 
COL INITIAL_SIZE FORMAT A10 
COL FINAL_SIZE FORMAT A10 
COL start_time format a20
COL changed_time format a20
select * from gv$sga_dynamic_components
where inst_id like nvl('&inst_id','%')
;
exit;
