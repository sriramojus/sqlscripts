set linesize 200
alter session set nls_date_format='YYYY:MM:DD:HH24:MI';
set verify off

column FS_FAILOVER_CURRENT_TARGET format a30 wrap heading 'FS_FAILOVER|CURRENT|TARGET'
column FS_FAILOVER_OBSERVER_PRESENT format a5 wrap heading 'FS_FAILOVER|OBSERVER|PRESENT'
column FS_FAILOVER_OBSERVER_HOST format a30 wrap heading 'FS_FAILOVER|OBSERVER|HOST'
column force_logging format a30  heading 'FORCE|LOGGING'
column DATAGUARD_BROKER heading 'DATAGUARD|BROKER'
select name as DATABASE,DB_UNIQUE_NAME, PROTECTION_MODE, PROTECTION_LEVEL,SWITCHOVER_STATUS, DATAGUARD_BROKER
from v$database; 

column CURRENT_SCN format 9999999999999999999999999999
column STANDBY_BECAME_PRIMARY_SCN format 99999999999999999999999999
select db_unique_name, open_mode,flashback_on,force_logging,log_mode,CONTROLFILE_TYPE,CURRENT_SCN,STANDBY_BECAME_PRIMARY_SCN 
from v$database;


select DB_UNIQUE_NAME,DATABASE_ROLE,OPEN_MODE,FS_FAILOVER_STATUS,FS_FAILOVER_THRESHOLD,FS_FAILOVER_CURRENT_TARGET,FS_FAILOVER_OBSERVER_HOST,
FS_FAILOVER_OBSERVER_PRESENT
from v$database;

prompt "Determine if real-time apply is enabled in Primary"

select dest_id, recovery_mode from v$archive_dest_status where dest_id  between 2 and 3;

prompt " Determone last failover reason "
column LAST_FAILOVER_REASON format a50 wrap
select *
FROM V$FS_FAILOVER_STATS;

prompt " Monitor database incrranation status"
column RESETLOGS_CHANGE# format 9999999999999999999999999
column PRIOR_RESETLOGS_CHANGE# format 9999999999999999999999999

select *
from V$DATABASE_INCARNATION;

prompt "Maximun archive sequence are received so far in DG Node"
select thread#,max(sequence#) as "Max Log Seq Received SoFar"
from v$archived_log where RESETLOGS_TIME=(select max(RESETLOGS_TIME) from v$archived_log) 
group by thread#
order by 1
/

prompt "Maximun archive sequence are generated so far in Primary RAC Nodes"

select thread#,max(sequence#) as "Max Seq Gen at Prim sofar" 
from v$archived_log where RESETLOGS_TIME=(select max(RESETLOGS_TIME) from v$archived_log)
group by thread#
order by 1 
/

column message format a100

SELECT MESSAGE,to_char(timestamp,'DD-MON-YYYY HH24:MI:SS')
FROM V$DATAGUARD_STATUS
where message like 'Media Recovery%'
and timestamp > sysdate - (&hours/24)
order by 2
/

select arch.thread# "Thread",arch.sequence# "Last Sequence Received",
       appl.sequence# "Last Sequence Applied",(arch.sequence# - appl.sequence#) "Difference"
from (select thread#,max(sequence#) as sequence#
      from v$archived_log
      where RESETLOGS_CHANGE# = (SELECT RESETLOGS_CHANGE# FROM V$DATABASE_INCARNATION  WHERE STATUS = 'CURRENT') 
      and archived = 'YES'
      group by thread#
      order by thread#
      ) arch,
      (select thread#,max(sequence#) as sequence#
      from v$archived_log
      where RESETLOGS_CHANGE# = (SELECT RESETLOGS_CHANGE# FROM V$DATABASE_INCARNATION  WHERE STATUS = 'CURRENT') 
      and applied = 'YES'
      group by thread#
      order by thread#
      ) appl
where arch.thread# = appl.thread#
order by 1
/

exit;
