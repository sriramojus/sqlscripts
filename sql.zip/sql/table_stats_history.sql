set linesize 200
column username format A10
column table_name format A20
column partition_name format a10
column object_type format a15
set verify off
set pages 99
set feedback off

accept owner prompt "Please Enter Owner Name :"
accept table_name prompt "Please Enter table Name:"

prompt "***************************************************"
prompt " Last_analyed column means  previous date of current analyze date "
prompt "stats_saved means when Current Analyzed date"
prompt " This history optstat_tab_history shows only last_analyzed records "
prompt " If you want stats_saved which is current analyzed date please run dba_table query"
prompt " If last_analyzed column value is null then probably delete statistics command run"
prompt "***************************************************"
SELECT u.name as username, o.name as table_name,o.subname as partition_name ,
decode(o.type#, 2, 'TABLE', 19, 'TABLE PARTITION', 34, 'TABLE SUBPARTITION', 'UNDEFINED' ) as object_type,
rowcnt num_rows, samplesize, case when rowcnt > 0 then round((samplesize/rowcnt)*100,2) else null end sample_pct, 
blkcnt blocks, avgrln avg_row_len, to_char(analyzetime,'DD-MON-YY HH24:MI:SS') last_analyzed,to_char(savtime,'DD-MON-YY HH24:MI:SS') as current_analyzed
FROM sys.user$ u, sys.obj$ o, sys.wri$_optstat_tab_history h
where  h.obj# = o.obj# and o.owner# = u.user# 
and u.name = upper('&owner') 
and o.name = upper('&table_name')  -- Change this to suit your condition
order by o.name, analyzetime;

prompt "*********************************************************"
prompt " Get Current  analyzed Details for tables from dba_table or dba_tab_partitions "
prompt " If last_analyzed column value is null then probably delete statistics command run"
prompt "*********************************************************"
set linesize 200
column owner format a10
column table_name format a20

select owner,table_name,partitioned,num_rows,status,
       to_char(last_analyzed,'DD-MON-YYYY HH24:MI') as last_analyzed,blocks,chain_cnt,temporary,user_stats,
       sample_size,decode(num_rows, 0, 1, (sample_size/num_rows)*100) est_pct
from dba_tables
where table_name like upper('&table_name')
and   owner = upper('&owner');

set linesize 200
column table_owner format a20
column table_name format a15
column partition_name format a10
column high_value format 9999999999
column tablespace_name format a20
column num_rows format 999999999
column logging format a7

select table_owner,table_name,partition_name,partition_position,global_stats,
 tablespace_name,num_rows,chain_cnt,logging,to_char(last_analyzed,'DD-MON-YYYY HH24:MI') as last_analyzed,
       sample_size,decode(num_rows, 0, 1, (sample_size/num_rows)*100) est_pct
from DBA_tab_partitions
where table_name = upper('&table_name')
and    table_owner = upper('&owner')
order by partition_position
;


exit;
