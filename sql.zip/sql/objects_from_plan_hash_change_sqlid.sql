set linesize 200
set verify off
set feedback off
set pages 99
prompt "********************************************SAMPLE OUTPUT********************************************************"
prompt    SQL_ID	      OBJECT_OWN              OBJECT_NAME				   OBJECT_TYPE
prompt "------------           ---------- -------------------------------------------------- -------------------"
prompt "59270v1qmz13y             APPS	          XXSAV_SHR_TEAM_MEMBERS_V			    VIEW"
prompt "59270v1qmz13y          SHAREADM	          JOB_TITLE_PK					    INDEX (UNIQUE)"
prompt "59270v1qmz13y          SHAREADM	         SHR_DENORM_VI_IX				    INDEX"
prompt "59270v1qmz13y          SHAREADM	         SHR_EMPLOYEES					    TABLE"

prompt               num_days :  how many days old sql's you want to check (default 1 day)

column object_owner format a15 wrap
column object_name format a50 wrap
column object_type format a20 wrap
select distinct q.sql_id,p.object_owner,p.object_name,p.object_type
from dba_hist_sqlstat q, dba_hist_snapshot s,dba_hist_sql_plan p
where s.snap_id = q.snap_id
and q.SQL_ID=trim('&sql_id')
and s.dbid = q.dbid
and s.dbid=p.dbid
and q.dbid=p.dbid
and s.instance_number = q.instance_number
and p.sql_id = q.sql_id
and p.object_type is not null
and s.begin_interval_time BETWEEN (SYSDATE - nvl(to_number('&num_days'),1)) AND SYSDATE
order by object_owner,object_name,object_type
/

exit;
