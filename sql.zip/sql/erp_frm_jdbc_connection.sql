prompt "***************************Forms Connection Details *******************************************"
prompt 
prompt
CLEAR  COL BREAK COMPUTE
SET    SERVEROUT ON LINES 200 VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT

COLUMN who      FORMAT A50
COLUMN How_Many FORMAT 999,999

SELECT inst_id,RPAD(machine||' : '||osuser||' : '||username||' : '||status,50,'.') who ,
       count(*) How_Many
FROM   gv$session
WHERE  program like 'frm%' OR action like '%frm%'
GROUP  BY inst_id,machine, osuser, username, status
ORDER  BY 3 desc
/ 

prompt
accept space prompt "Please Press Enter for Continue ...................................."
prompt
prompt
prompt

prompt "*******************************JDBC Connection Details ***************************"
prompt
prompt

CLEAR  COL BREAK COMPUTE
SET    SERVEROUT ON LINES 200 VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT

COLUMN who      FORMAT A50
COLUMN How_Many FORMAT 999,999

SELECT inst_id,RPAD(machine||' : '||osuser||' : '||username||' : '||status,50,'.') who ,
       count(*) How_Many
FROM   gv$session
WHERE  program like 'JDBC%'
GROUP  BY inst_id,machine, osuser, username, status
ORDER  BY 3 desc
/
prompt
prompt
exit;
