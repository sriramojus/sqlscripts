PROMPT ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
PROMPT ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
PROMPT
PROMPT EXCLUDED UNUSABLE INDEXES/INDEX PARTITIONS/DOMAIN INDEXES/DOMAIN INDEXES PARTITIONS
PROMPT ==================================================================================
PROMPT
PROMPT  EXCLUDED INDEXES IN PRODUCTION FOCUS
PROMPT  ------------------------------------

col owner for a11
col index_name for a24
col table_owner for a12
col table_name for a24
set linesize 300

select 
        a.owner,
        a.index_name,
        a.table_owner,
        a.table_name,
        a.status,
        to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time" 
from 
        dba_indexes a,
        dba_objects b
where 
        a.status='UNUSABLE'
        and a.owner=b.owner
        and a.index_name=b.object_name
        and b.object_type='INDEX' 
        and a.index_name in (SELECT details FROM ops$oracle.production_focus_exceptions 
        WHERE CATEGORY in ('INVALID_DOMAIN_INDEXES','UNUSABLE_INDEXES','UNUSABLEIDX') AND action_to_take = 'EXCLUDE')
        order by b.last_ddl_time;

PROMPT
PROMPT  EXCLUDED INDEX PARTITIONS IN PRODUCTION FOCUS 
PROMPT  ---------------------------------------------       

col index_owner for a15
col index_name for a20
col partition_name for a20
col status for a10

select 
        a.index_owner,
        a.index_name,
        a.partition_name,
        a.status,
        to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time" 
from 
        dba_ind_partitions a,
        dba_objects b
where 
        a.status='UNUSABLE'
        and a.index_owner=b.owner
        and a.index_name=b.object_name
        and a.partition_name=b.SUBOBJECT_NAME
        and b.object_type='INDEX PARTITION'
        and a.index_name in (SELECT details FROM ops$oracle.production_focus_exceptions 
        WHERE CATEGORY in ('INVALID_DOMAIN_INDEXES','UNUSABLE_INDEXES','UNUSABLEIDX') AND action_to_take = 'EXCLUDE')
        order by b.last_ddl_time;
        
PROMPT
PROMPT  EXCLUDED FAILED DOMAIN INDEXES IN PRODUCTION FOCUS 
PROMPT  --------------------------------------------------

col index_owner for a15
col index_name for a20
col partition_name for a20
col status for a10

select
        a.owner,
        a.index_name,
        a.table_owner,
        a.table_name,
        a.status,
        to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time"
from
        dba_indexes a,
        dba_objects b
where
        a.DOMIDX_OPSTATUS='FAILED'
        and a.owner=b.owner
        and a.index_name=b.object_name
        and b.object_type='INDEX'
        and a.index_name in (SELECT details FROM ops$oracle.production_focus_exceptions 
        WHERE CATEGORY in ('INVALID_DOMAIN_INDEXES','UNUSABLE_INDEXES','UNUSABLEIDX') AND action_to_take = 'EXCLUDE')
        order by b.last_ddl_time;
       
PROMPT
PROMPT  EXCLUDED FAILED DOMAIN INDEXES PARTITIONS IN PRODUCTION FOCUS 
PROMPT  -------------------------------------------------------------

select
        a.index_owner,
        a.index_name,
        a.partition_name,
        a.status,
        to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time"
from
        dba_ind_partitions a,
        dba_objects b
where
        a.DOMIDX_OPSTATUS='FAILED'
        and a.index_owner=b.owner
        and a.index_name=b.object_name
        and a.partition_name=b.SUBOBJECT_NAME
        and b.object_type='INDEX PARTITION'
        and a.index_name in (SELECT details FROM ops$oracle.production_focus_exceptions 
        WHERE CATEGORY in ('INVALID_DOMAIN_INDEXES','UNUSABLE_INDEXES','UNUSABLEIDX') AND action_to_take = 'EXCLUDE')
        order by b.last_ddl_time;

PROMPT ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
PROMPT ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
PROMPT
PROMPT CURRENT UNUSABLE INDEXES/INDEX PARTITIONS/DOMAIN INDEXES/DOMAIN INDEXES PARTITIONS
PROMPT ==================================================================================

PROMPT
PROMPT  UNUSABLE INDEXES
PROMPT  ----------------

col owner for a11
col index_name for a24
col table_owner for a12
col table_name for a24
set linesize 300

select 
        a.owner,
        a.index_name,
        a.table_owner,
        a.table_name,
        a.status,
        to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time" 
from 
        dba_indexes a,
        dba_objects b
where 
        a.status='UNUSABLE'
        and a.owner=b.owner
        and a.index_name=b.object_name
        and b.object_type='INDEX' 
        and a.index_name not in (SELECT details FROM ops$oracle.production_focus_exceptions 
        WHERE CATEGORY in ('INVALID_DOMAIN_INDEXES','UNUSABLE_INDEXES','UNUSABLEIDX') AND action_to_take = 'EXCLUDE')
        order by b.last_ddl_time;

PROMPT
PROMPT  UNUSABLE INDEX PARTITIONS
PROMPT  -------------------------

col index_owner for a15
col index_name for a20
col partition_name for a20
col status for a10

select 
        a.index_owner,
        a.index_name,
        a.partition_name,
        a.status,
        to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time" 
from 
        dba_ind_partitions a,
        dba_objects b
where 
        a.status='UNUSABLE'
        and a.index_owner=b.owner
        and a.index_name=b.object_name
        and a.partition_name=b.SUBOBJECT_NAME
        and b.object_type='INDEX PARTITION'
        and a.index_name not in (SELECT details FROM ops$oracle.production_focus_exceptions 
        WHERE CATEGORY  in ('INVALID_DOMAIN_INDEXES','UNUSABLE_INDEXES','UNUSABLEIDX') AND action_to_take = 'EXCLUDE')
        order by b.last_ddl_time;

PROMPT
PROMPT  FAILED DOMAIN INDEXES
PROMPT  ---------------------

col owner for a11
col index_name for a24
col table_owner for a12
col table_name for a24
set linesize 300

select
        a.owner,
        a.index_name,
        a.table_owner,
        a.table_name,
        a.status,
        to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time"
from
        dba_indexes a,
        dba_objects b
where
        a.DOMIDX_OPSTATUS='FAILED'
        and a.owner=b.owner
        and a.index_name=b.object_name
        and b.object_type='INDEX'
        and a.index_name not in (SELECT details FROM ops$oracle.production_focus_exceptions 
        WHERE CATEGORY in ('INVALID_DOMAIN_INDEXES','UNUSABLE_INDEXES','UNUSABLEIDX') AND action_to_take = 'EXCLUDE')
        order by b.last_ddl_time;

PROMPT
PROMPT  FAILED DOMAIN INDEX PARTITIONS
PROMPT  ------------------------------

col index_owner for a15
col index_name for a20
col partition_name for a20
col status for a10

select
        a.index_owner,
        a.index_name,
        a.partition_name,
        a.status,
        to_char(b.last_ddl_time,'DD-MON-YYYY HH24:MI:SS') "Last DDL Time"
from
        dba_ind_partitions a,
        dba_objects b
where
        a.DOMIDX_OPSTATUS='FAILED'
        and a.index_owner=b.owner
        and a.index_name=b.object_name
        and a.partition_name=b.SUBOBJECT_NAME
        and b.object_type='INDEX PARTITION'
        and a.index_name not in (SELECT details FROM ops$oracle.production_focus_exceptions 
        WHERE CATEGORY in ('INVALID_DOMAIN_INDEXES','UNUSABLE_INDEXES','UNUSABLEIDX') AND action_to_take = 'EXCLUDE')
        order by b.last_ddl_time;
exit;
