set lines 300 pages 500
select
	  vs.inst_id
	, vs.sid
	, vs.serial#
	, vs.machine
from
	  apps.fnd_concurrent_requests fcr
	, apps.fnd_concurrent_processes fcp
	, apps.fnd_user fu
	, gv$session vs
	, gv$process vp
	, apps.fnd_concurrent_programs_tl pn
where
	    fcr.controlling_manager = fcp.concurrent_process_id
	and fcr.status_code in ('X')
	and (fcr.program_application_id = pn.application_id and fcr.concurrent_program_id  = pn.concurrent_program_id )
	and fcr.requested_by = fu.user_id
	and vp.spid = fcr.oracle_process_id
	and vp.inst_id = fcp.INSTANCE_NUMBER
	and vp.inst_id = vs.inst_id
	and vs.paddr = vp.addr
	and fcr.actual_completion_date between (sysdate - 8/24) and (sysdate - 5/1440)
	and vs.logon_time between fcr.requested_start_date and  fcr.actual_completion_date
;
exit;
