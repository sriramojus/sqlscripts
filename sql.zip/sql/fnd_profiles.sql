SET heading OFF  feed off verify off
set lines 200
COLUMN "Profile" FORMAT A50 word_wrapped 
COLUMN "Value" FORMAT A30  word_wrapped 
COLUMN "Levl" FORMAT A4 
COLUMN "Location" FORMAT A25  word_wrapped 
BREAK ON "Profile" ON "Value" ON "Levl"

ACCEPT v_profile PROMPT "Enter a PROFILE substring value to search (default 'ALL PROFILES') : " 
ACCEPT v_username PROMPT "Enter a USER / LOCATION or substring to search (default 'ALL USERS') : "
ACCEPT v_profval PROMPT "Enter a PROFILE VALUE substring to search (default 'No String') : "

SELECT 'Querying ' || name || TO_CHAR( sysdate, '" on" dd-Mon-yyyy "for"') 
 || 'Profile like ''%' || UPPER( '&&v_profile') 
 || '%'' and User / Location like ''%' || UPPER( '&&v_username')   || '%''' 
--Showing the query parameters 
FROM v$database,   dual 
/

SET heading ON 
set pagesize 60 
set newpage  0 
--Now set the column headers on that we have specified above 
SELECT pot.user_profile_option_name "Profile" 
 , DECODE( a.profile_option_value 
          , '1', '1 (may be "Yes")' 
          , '2', '2 (may be "No")' 
          , a.profile_option_value) "Value" 
 , DECODE( a.level_id 
          , 10001, 'Site' 
          , 10002, 'Appl' 
          , 10003, 'Resp' 
          , 10004, 'User' 
          , '????') "Levl" 
 , DECODE( a.level_id 
          , 10002, e.application_name 
          , 10003, c.responsibility_name 
          , 10004, d.user_name 
          , '-') "Location" 
, to_char(a.last_update_date,'DD-MON-YYYY HH24:MI:SS') "Last Modified"
FROM applsys.fnd_application_tl e 
 , applsys.fnd_user d   , applsys.fnd_responsibility_tl c 
 , applsys.fnd_profile_option_values a   , applsys.fnd_profile_options b 
 , applsys.fnd_profile_options_tl pot 
WHERE UPPER( pot.user_profile_option_name) LIKE UPPER( '%&&v_profile%') 
 AND pot.profile_option_name = b.profile_option_name 
 AND b.application_id = a.application_id (+) 
 AND b.profile_option_id = a.profile_option_id (+) 
 AND a.level_value = c.responsibility_id (+) 
 AND a.level_value = d.user_id (+)   AND a.level_value = e.application_id 
(+) 
 AND( UPPER( e.application_name) LIKE UPPER( '%&&v_username%') 
 OR UPPER( c.responsibility_name) LIKE UPPER( '%&&v_username%') 
 OR UPPER( d.user_name) LIKE UPPER( '%&&v_username%')) 
AND UPPER( a.profile_option_value) LIKE UPPER( '%&&v_profval%')
 ORDER BY "Profile", "Levl", "Location", "Value" 
;
exit;
