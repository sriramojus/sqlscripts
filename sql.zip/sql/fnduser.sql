prompt " FND Users Details "
column user_name format a20
column user_guid format a10
column ENCRYPTED_FOUNDATION_PASSWORD format a30
column ENCRYPTED_USER_PASSWORD format a30
set linesize 200
set pagesize 80

select user_id,user_name,user_guid,ENCRYPTED_FOUNDATION_PASSWORD,ENCRYPTED_USER_PASSWORD,to_char(end_date,'DD-MON-YYYY') as End_Date
from apps.fnd_user
where user_name like UPPER('&FNDusername%')
/

select user_name,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATION_DATE,CREATED_BY,LAST_UPDATE_LOGIN
from apps.fnd_user
where user_name like UPPER('&FNDusername%')
/
exit;
