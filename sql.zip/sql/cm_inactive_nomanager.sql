set linesize 200
set pages 99

PROMPT    ************************************************
prompt " Concurrent requests counts having INACTIVE and NOMANAGER STATUS"
PROMPT    ************************************************

select count(r.request_id) 
from applsys.fnd_concurrent_programs p,applsys.fnd_concurrent_requests r 
where p.concurrent_program_id=r.concurrent_program_id 
and p.application_id=r.program_application_id and p.enabled_flag <> 'N' 
and r.phase_code = 'P' and r.status_code <> 'A' and r.hold_flag <> 'Y' 
and not (r.requested_start_date > sysdate or r.status_code = 'P') and 
not exists (select 1 from apps.fnd_concurrent_worker_requests wr 
             where wr.request_id = r.request_id and wr.running_processes > 0 
             and (not (wr.queue_application_id = 0 and wr.concurrent_queue_id in (1,4)) 
             or wr.queue_control_flag = 'Y'))
/

PROMPT    ************************************************
prompt " Concurrent requests details having  INACTIVE and NOMANAGER STATUS"
PROMPT    ************************************************
set linesize 200
column user_concurrent_program_name format a40 wrap
column user_name format a30 wrap

select r.request_id, pt.user_concurrent_program_name, 'Inactive NoManager', 
to_char(r.requested_start_date,'MM/DD/YY HH24:MI:SS'), u.user_name 
from applsys.fnd_concurrent_programs p,applsys.fnd_concurrent_requests r, 
     applsys.fnd_concurrent_programs_tl pt,applsys.fnd_user u 
where pt.application_id=p.application_id 
and p.concurrent_program_id=pt.concurrent_program_id 
and r.requested_by=u.user_id and p.concurrent_program_id=r.concurrent_program_id 
and p.application_id=r.program_application_id 
and p.enabled_flag <> 'N' and r.phase_code = 'P' 
and r.status_code <> 'A' and r.hold_flag <> 'Y' 
and pt.language = 'US'
and not (r.requested_start_date > sysdate or r.status_code = 'P') 
and not exists (select 1 from apps.fnd_concurrent_worker_requests wr 
                where wr.request_id = r.request_id and wr.running_processes > 0 
                and (not (wr.queue_application_id = 0 and wr.concurrent_queue_id in (1,4)) 
                or wr.queue_control_flag = 'Y')) order by r.request_id 
/
exit;
