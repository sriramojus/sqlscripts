set lines 200 pages 100 verify off
accept days char prompt 'Enter Days for last_ddl_time (Default - 180): '
PROMPT
PROMPT Tables having degree more than 1
PROMPT
SELECT
a.OWNER, a.TABLE_NAME, TRIM(a.DEGREE), b.last_ddl_time
FROM
DBA_TABLES a, dba_objects b
WHERE
a.owner=b.owner
and
a.table_name=b.object_name
and b.last_ddl_time > (sysdate -nvl('&days',180))
and
TRIM(a.DEGREE) > TO_CHAR(1)
;

PROMPT
PROMPT Indexes having degree more than 1
PROMPT

SELECT
a.OWNER, a.INDEX_NAME, TRIM(a.DEGREE), b.last_ddl_time
FROM
DBA_INDEXES a, dba_objects b
WHERE
a.owner=b.owner
and
a.index_name=b.object_name
and b.last_ddl_time > (sysdate -nvl('&days',180))
and
TRIM(a.DEGREE) > TO_CHAR(1);
exit;
