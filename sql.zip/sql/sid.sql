SET LINESIZE 200 pages 1000
SET VERIFY off feed off
set heading on
prompt "Please Enter specific value if you know already otherwise just press Enter for each input which would display gobal sessions details "
prompt "*****************************************************************************************************************************"
prompt
prompt
COL Active4 FOR A6   HEAD "Status"
COL sid     FOR 99999999999  HEAD "Sid"
COL spid    FOR A6   HEAD "  Spid"
COL proces  FOR A6   HEAD "Proces" TRUNC
COL usr     FOR A50  HEAD "OraUsr(OsUsr)Machine" TRUN
COL hoo     FOR A50  HEAD "Module(Program)Action" TRUN

SELECT v.inst_id,v.sid sid,sql_id,LPAD(p.spid,6) spid, LPAD(nvl(v.process,'N/A'),6) proces,
       v.username||'('||v.osuser||')'||v.machine usr,
       NVL(module,'x')||'('||
       NVL(v.program,'x')||')'||NVL(action,'x') hoo,
       SUBSTR(v.status,1,1) ||
       LPAD(((last_call_et/60)-mod((last_call_et/60),60))/60,2,'0') ||':'||
       LPAD(ROUND(mod((last_call_et/60),60)),2,'0') Active4
FROM   gv$session v, gv$process p
WHERE  v.paddr = p.addr
AND    v.inst_id=p.inst_id
AND    v.inst_id LIKE NVL('&inst_id','%')
AND    v.sid LIKE NVL('&sid','%')
AND    p.spid LIKE NVL('&OS_ProcessID','%')
AND    v.process LIKE NVL('&Client_ProcessID','%')
AND    upper(v.username) LIKE UPPER(NVL('&ora_user','%'))
AND    UPPER(v.osuser)   LIKE UPPER(NVL('&os_usr','%'))
AND    UPPER(v.machine)  LIKE UPPER(NVL('&machine','%'))
AND    UPPER(v.module)   LIKE UPPER(NVL('&module','%'))
ORDER  BY v.inst_id,v.sid
/
prompt
prompt
prompt
prompt "Please Input specific SID along with INSTANCE NUMBER for getting more Session detail informations "
prompt "******************************************************************************************"
set heading off
set verify off
set feedback off

undefine sid_number
undefine spid_number
accept inst_num number prompt "Enter inst_id :"
accept sid_number number prompt "pl_enter_sid:"
col sid NEW_VALUE sid_number noprint
col inst_id  NEW_VALUE inst_num noprint
define sid_def = "&sid_number" (number)

prompt "********************************************************************************"
PROMPT "       Individual  Session and Process detail informations    "
PROMPT " *******************************************************************************"


col event for a30
col module for a50

select '    INST_ID  	       		: '||v.inst_id 	|| chr(10)|| 
       '    SID  	       		: '||v.sid 	|| chr(10)|| 
       '    Serial Number		: '||v.serial# 	|| chr(10) ||
       '    Oracle User Name 		: '||v.username 	|| chr(10) ||
       '    Client OS user name		: '||v.osuser 	|| chr(10) ||
       '    Client Process ID	 	: '||v.process 	|| chr(10) ||
       '    Client machine Name 	: '||v.machine 	|| chr(10) ||
       '    Oracle PID 		 	: '||p.pid 	|| chr(10) ||
       '    OS Process ID(spid)	 	: '||p.spid 	|| chr(10) ||
       '    Session''s Status	  	: '||v.status 	|| chr(10) ||
       '    last call et(mins)          : '||round(v.last_call_et/60)   || chr(10) ||
       '    Logon Time		  	: '||to_char(v.logon_time, 'MM/DD HH24:MIpm')  	|| chr(10) ||
       '    Program Name	 	: '||v.program 	|| chr(10) ||
       '    Module Name	 		: '||v.module 	|| chr(10) ||
       '    Action	 		: '||v.action 	|| chr(10) 
from gv$session v, gv$process p
where v.paddr = p.addr
and   v.inst_id=p.inst_id
-- and v.serial# > 1
-- and p.background is null
-- and p.username is not null
and v.inst_id = &inst_num
and v.sid = decode('&sid_number',0,'&sid_def','&sid_number')
order by v.logon_time, v.status, 1
/


PROMPT SQL_ID           HASH_VALUE   PREV_SQL_ID   PREV_HASH_VALUE
PROMPT -----------------------------------------------------------

select distinct s.sql_id sql_id,SQL_HASH_VALUE,PREV_SQL_ID,PREV_HASH_VALUE
from gv$sqltext , gv$session s
where gv$sqltext.address = s.sql_address
and gv$sqltext.inst_id = s.inst_id
and sid = decode('&sid_number',0,'&sid_def','&sid_number') 
and s.inst_id = &inst_num
/

PROMPT
PROMPT Sql Statement
PROMPT --------------

select sql_text
from gv$sqltext , gv$session
where gv$sqltext.address = gv$session.sql_address
and gv$sqltext.inst_id = gv$session.inst_id
and sid = decode('&sid_number',0,'&sid_def','&sid_number') 
and gv$session.inst_id = &inst_num
order by piece
/

PROMPT
PROMPT Event Wait Information
PROMPT ----------------------

select '   SID '|| &sid_number || ' on instance '|| &inst_num ||' is waiting on event	: ' || x.event || chr(10) ||
       '   P1 Text 		  	: ' || x.p1text || chr(10) ||
       '   P1 Value 		  	: ' || x.p1 || chr(10) ||
       '   P2 Text 		  	: ' || x.p2text || chr(10) ||
       '   P2 Value 		  	: ' || x.p2 || chr(10) ||
       '   P3 Text 		  	: ' || x.p3text || chr(10) ||
       '   P3 Value 		  	: ' || x.p3 
from gv$session_wait x
where x.sid= decode('&sid_number',0,'&sid_def','&sid_number') 
and   x.inst_id = &inst_num
and x.wait_time=0
/

PROMPT
PROMPT Session Statistics
PROMPT ------------------

select        '     '|| b.name  ||'   		: '||decode(b.name, 'redo size', round(a.value/1024/1024,2)||' M', a.value) 
from gv$session s, gv$sesstat a, gv$statname b
where a.statistic# = b.statistic#
and name in ('redo size', 'parse count (total)', 'parse count (hard)', 'user commits')
and a.inst_id = b.inst_id
and s.inst_id = a.inst_id
and s.inst_id = b.inst_id
and a.inst_id = &inst_num
and s.sid = decode('&sid_number',0,'&sid_def','&sid_number') 
and a.sid = decode('&sid_number',0,'&sid_def','&sid_number') 
--order by b.name
order by decode(b.name, 'redo size', 1, 2), b.name
/

COLUMN USERNAME FORMAT a10
COLUMN status FORMAT a8
column RBS_NAME format a10


PROMPT
PROMPT Transaction and Rollback Information
PROMPT ------------------------------------

select        '    Rollback Used                : '||t.used_ublk*8192/1024/1024 ||' M' || chr(10) ||
              '    Rollback Records             : '||t.used_urec        || chr(10)||
              '    Rollback Segment Number      : '||t.xidusn           || chr(10)||
              '    Logical IOs                  : '||t.log_io           || chr(10)||
              '    Physical IOs                 : '||t.phy_io           || chr(10)||
              '    RBS Startng Extent ID        : '||t.start_uext       || chr(10)||
              '    Transaction Start Time       : '||t.start_time       || chr(10)||
              '    Transaction_Status           : '||t.status
FROM gv$transaction t, gv$session s
WHERE t.addr = s.taddr
and t.inst_id = s.inst_id
and s.sid = decode('&sid_number',0,'&sid_def','&sid_number') 
and s.inst_id = &inst_num
/

PROMPT
PROMPT Sort Information
PROMPT ---------------- 

column username format a20
column user format a20
column tablespace format a20

SELECT        '    Sort Space Used(8k block size is asssumed	: '||u.blocks/1024*8 ||' M'		|| chr(10) ||
              '    Sorting Tablespace 		  		: '||u.tablespace	|| chr(10)|| 
              '    Sort Tablespace Type		 	: '||u.contents	|| chr(10)|| 
              '    Total Extents Used for Sorting 		: '||u.extents	
FROM gv$session s, gv$sort_usage u
WHERE s.saddr = u.session_addr
AND s.inst_id = u.inst_id
AND s.sid = decode('&sid_number',0,'&sid_def','&sid_number') 
AND s.inst_id = &inst_num
/
prompt
prompt
prompt
prompt
prompt
prompt
prompt " *******************************************************************************************"
prompt "   This Below output for ERP Database  Session Detail Informations based on SID and INST_ID "      
prompt " *******************************************************************************************"
set serveroutput on
set autoprint on
variable x refcursor;
DECLARE
l_action VARCHAR2(32);
BEGIN
        select ACTION into l_action from gv$session v where  v.inst_id = &inst_num and v.sid = decode('&sid_number',0,'&sid_def','&sid_number');
        IF l_action = 'Concurrent Request' then
        dbms_output.put_line('Concurrent Request Information');
        dbms_output.put_line('------------------------------');
        open :x for select  '    Request Id                 : '||c.request_id || chr(10)||
                            '    Status Code                : '||status_code        || chr(10) ||
                            '    Phase Code                 : '||phase_code || chr(10) ||
                            '    Concurrent Program         : '||user_concurrent_program_name       || chr(10)
                from gv$session s, gv$process p, apps.fnd_concurrent_requests c,apps.fnd_concurrent_programs_tl ct, apps.fnd_user d
                where oracle_process_id=p.spid
                and s.paddr=p.addr and
                ct.concurrent_program_id=c.concurrent_program_id
                and c.requested_by = d.user_id
                and c.status_code='R'
                and c.phase_code='R'
                and s.sid = decode('&sid_number',0,'&sid_def','&sid_number')
                and s.inst_id = &inst_num ;
        ELSE
                open :x for select '' from dual;
       END IF;
END;
/
set serveroutput off
set heading on
set verify on

clear column
