CLEAR  COL BREAK COMPUTE
SET    PAGESIZE 500 VERIFY OFF PAUSE OFF FEEDBACK OFF LINES 200
COLUMN tablespace_name   FORMAT A20
COLUMN in_M              FORMAT 9999
COLUMN nx_M              FORMAT 9999
COLUMN pct               FORMAT 99       HEADING %I
COLUMN status            FORMAT A5       HEADING STATE      TRUNC
COLUMN contents          FORMAT A9
COLUMN logging           FORMAT A7                          TRUNC
COLUMN extent_management FORMAT A10       HEADING EXTNT_MGMT     TRUNC
COLUMN allocation_type   FORMAT A10       HEADING ALLOCATION TRUNC
COLUMN segment_space_management  FORMAT A12       HEADING SEG_SPC_MGMT     TRUNC
compute sum of TOTAL_SPACE_IN_MB FREE_SPACE_IN_MB chunk on report
break on report
accept tablespace_name char prompt 'Enter Tablespace Name [Just press Enter for all tablespaces]:'
WITH free_space AS (select TABLESPACE_NAME, bytes, count(1) cnt from dba_free_space where (TABLESPACE_NAME, bytes) in (select TABLESPACE_NAME, max(bytes) from dba_free_space group by TABLESPACE_NAME) group by TABLESPACE_NAME, bytes)
select 
	a.TABLESPACE_NAME
	, round(a.bytes_used/(1024*1024),2) TOTAL_SPACE_IN_MB
	, round(b.bytes_free/(1024*1024),2) FREE_SPACE_IN_MB
	, round(b.largest/(1024*1024),2) max_chunk_in_MB
	, round(((a.bytes_used-b.bytes_free)/a.bytes_used)*100,2) percent_used
	, c.cnt chunks_cnt
	, d.extent_management
        , d.allocation_type
        , d.segment_space_management
from
	(select TABLESPACE_NAME, sum(bytes) bytes_used from dba_data_files group by TABLESPACE_NAME) a
	, (select TABLESPACE_NAME, sum(BYTES) bytes_free, max(BYTES) largest from dba_free_space group by TABLESPACE_NAME) b
	, free_space c
	, dba_tablespaces d
where
	a.TABLESPACE_NAME=b.TABLESPACE_NAME(+)
	and a.tablespace_name=c.tablespace_name
	and a.tablespace_name=d.tablespace_name
	and d.contents = 'PERMANENT'
--	and a.tablespace_name not in (select details from ops$oracle.production_Focus_Exceptions where category='CHK_SPACE' and action_to_Take = 'EXCLUDE')
	and a.tablespace_name = decode(upper('&tablespace_name'),null,a.tablespace_name,upper('&tablespace_name'))
order by 
	((a.BYTES_used-b.BYTES_free)/a.BYTES_used) desc;
SET   VERIFY OFF FEEDBACK ON ECHO OFF PAGES 32 PAUSE OFF
exit;
