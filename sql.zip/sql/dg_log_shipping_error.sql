column ID format 999
column DB_status format a10
column Archive_dest format a40
column Error format a30 wrap
set linesize 200
SELECT inst_id,DEST_ID "ID", STATUS "DB_status", DESTINATION "Archive_dest", ERROR "Error" 
FROM GV$ARCHIVE_DEST WHERE DEST_ID <=4;

exit;
