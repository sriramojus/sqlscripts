column segment_name format a32
column segment_type format a17
col tablespace_name format a17
column owner format a15
column initial(MB) format 99,99.99
column next(MB) format 99,99.99
set linesize 200
set pagesize 100 verify off feed off
accept sizeinmb char prompt 'Enter Size in MB(Default - 100M):'
accept tbsname char prompt 'Enter Tablespace Name :'
select  segment_name,
     	segment_type,
        owner,
	tablespace_name,
	initial_extent/1024/1024 "initial(MB)", 
        next_extent/1024/1024    "next(MB)",
	round(bytes/1024/1024,0) "Size (MB)",
	extents,
	pct_increase pct_inc
FROM	dba_segments
where	
bytes/1024/1024 > nvl('&sizeinmb',100)
and tablespace_name = upper(nvl('&tbsname',tablespace_name))
order by bytes/1024/1024;
exit;
