set pages 100
set lines 200
col username form a20
col osuser for a15
col machine format a20
col qcsid format 999999
select 
	a.qcsid,
	b.serial#,
	a.cnt "No of parallel threads",
	b.osuser,
	b.username,
 	b.sql_hash_value,
	b.machine
from
(select qcsid,count(*) cnt from v$px_session group by qcsid) a,
v$session b 
where
a.qcsid=b.sid;

accept qcsid char prompt 'Enter specific qcsid for more details : '
CLEAR  COL BREAK COMPUTE
SET    LINES 200 PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT
col event format a30
COL Active4 FOR A7  HEAD STATUS
COL sssu    FOR A28 HEAD "  SPID   SID SERIAL# UPID"
COL hoo     FOR A68 HEAD "USERNAME [ OSUSER ] MACHINE [ MODULE ] PROGRAM [ ACTION ]" TRUN

SELECT v.username||'['||v.osuser||']'||v.machine||'['||NVL(module,'x')||']'||
       NVL(v.program,'x')||'['||NVL(action,'x')||']' hoo,
       LPAD(NVL(p.spid,'x'),6)||' '||LPAD(v.sid,5)||'  '||LPAD(v.serial#,5) sssu,
       SUBSTR(v.status,1,1) ||
       LPAD(((last_call_et/60)-mod((last_call_et/60),60))/60,2,'0') ||':'||
       LPAD(ROUND(mod((last_call_et/60),60)),2,'0')||'H' Active4,
	sw.event
FROM   v$session v, v$process p, v$session_wait sw
WHERE  v.paddr = p.addr
and v.sid=sw.sid
and v.sid in (select sid from v$px_session where qcsid=nvl('&qcsid',999999))
ORDER  BY status, last_call_et;
exit;
