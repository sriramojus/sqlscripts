PROMPT
PROMPT Displays tables if total_rows >10000 and if percentage change is >10
PROMPT
set lines 300 pages 100 verify off
accept owner char prompt 'Enter Owner:(Default - All) :'
accept table_name char prompt 'Enter Table Name:(Default - All) :'
select a.owner,a.tab_name,a.anlyzd_rows,a.last_anlzd,a.tot_rows,a.inserts,a.deletes,a.updates,a.pct,a.trn from
(select dbta.owner owner,dbta.table_name       tab_name
     ,dbta.num_rows                  anlyzd_rows
     ,to_char(dbta.last_analyzed,'yyyy-mm-dd hh24:mi:ss')  last_anlzd
     ,nvl(dbta.num_rows,0)+nvl(dtm.inserts,0)
      -nvl(dtm.deletes,0)               tot_rows,
nvl(dtm.inserts,0) inserts,
nvl(dtm.deletes,0) deletes,
nvl(dtm.updates,0) updates,
    decode(sign(round(100-(nvl(dbta.num_rows,0)+nvl(dtm.inserts,0)-nvl(dtm.deletes,0))/greatest(nvl(dbta.num_rows,0),1)*100)),-1,(round(100-(nvl(dbta.num_rows,0)+nvl(dtm.inserts,0)-nvl(dtm.deletes,0))/greatest(nvl(dbta.num_rows,0),1)*100))*-1,round(100-(nvl(dbta.num_rows,0)+nvl(dtm.inserts,0)-nvl(dtm.deletes,0))/greatest(nvl(dbta.num_rows,0),1)*100)) pct
    ,dtm.truncated                  trn
from         dba_tables            dbta
left outer join sys.dba_tab_modifications dtm
   on  dbta.owner         = dtm.table_owner
   and dbta.table_name    = dtm.table_name
   and dtm.partition_name is null
where
dbta.owner=upper(nvl('&owner',dbta.owner))
and dbta.table_name =upper(nvl('&table_name',dbta.table_name))
and dbta.owner    not in ('SYS','SYSTEM','OPS$ORACLE','PERF11I','AQADM','GESADM')
and dtm.truncated<>'YES'
) a,dba_tab_statistics b
where
a.owner=b.owner
and a.tab_name=b.table_name
and (a.owner,a.tab_name) not in (select log_owner,log_table from dba_snapshot_logs)
and nvl(b.stattype_locked,'NO')='NO'
and tot_rows>10000
and pct>=10
order by pct desc;
exit;
