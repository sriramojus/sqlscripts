prompt " Current Parameter setting for memory parameters"
prompt "***************************************************"
set pagesize 50
set linesize 200
column name format a40
column description format a60
column display_value format a20  heading "Value"

SELECT inst_id,name, display_value, description
FROM gv$parameter
WHERE name IN
            ('sga_target','sga_max_size',
             'memory_target',
             'memory_max_target',
             'pga_aggregate_target',
             'shared_pool_size',
             'large_pool_size',
             'java_pool_size')
      OR name LIKE 'db%cache_size'
      OR name LIKE 'pga%'
and  inst_id like nvl('&inst_id','%')
ORDER BY inst_id,name;

column sga format 9999999 heading "SGA|Alloc(MB)"
column pga format 9999999 heading "PGA|Alloc(MB)"
column pool format a20 wrap

prompt " SGA  as well as PGA  Allocated Memory History"
prompt "**************************************"	

select sn.INSTANCE_NUMBER, sga.allo sga, pga.allo pga,(sga.allo+pga.allo) tot,to_char(SN.END_INTERVAL_TIME,'dd-mon-yyyy HH24') time
from
(select snap_id,INSTANCE_NUMBER,round(sum(bytes)/1024/1024,3) allo 
   from DBA_HIST_SGASTAT 
  group by snap_id,INSTANCE_NUMBER) sga
,(select snap_id,INSTANCE_NUMBER,round(sum(value)/1024/1024,3) allo 
    from DBA_HIST_PGASTAT where name = 'total PGA allocated' 
   group by snap_id,INSTANCE_NUMBER) pga
, dba_hist_snapshot sn 
where sn.snap_id=sga.snap_id
  and sn.INSTANCE_NUMBER=sga.INSTANCE_NUMBER
  and sn.snap_id=pga.snap_id
  and sn.INSTANCE_NUMBER=pga.INSTANCE_NUMBER
  and sn.end_interval_time > SYSDATE - &daysold
  and sn.INSTANCE_NUMBER like nvl('&inst_id','%')
order by sn.snap_id desc,to_char(SN.END_INTERVAL_TIME,'dd-mon-yyyy HH24') asc 
;
exit;
