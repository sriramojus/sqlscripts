set linesize 200 verify off pages 1000 feed off
prompt
accept days char prompt 'How many days(Default - 1 day) :'
prompt
accept instno char prompt 'Enter instance number(Default - All ) :'
prompt
select 
        /*+parallel(a,8) parallel(b,8)*/
        to_char(COMPLETION_TIME,'DD-MON-YYYY') , inst_id,
        ROUND( SUM( blocks * block_size ) / 1024 / 1024 / 1024 ) archive_size_in_gb
from    
        v$archived_log a,gv$instance b
where 
        a.thread#=b.inst_id
        and COMPLETION_TIME >= to_date( to_char(COMPLETION_TIME,'DD-MON-YYYY'),'DD/MM/YYYY')
        and standby_dest='NO'
        and trunc(COMPLETION_TIME)>sysdate-nvl('&days',1)
        and inst_id=nvl('&instno',inst_id)
        group by to_char(COMPLETION_TIME,'DD-MON-YYYY') ,inst_id order by 1,2;
prompt
exit;
