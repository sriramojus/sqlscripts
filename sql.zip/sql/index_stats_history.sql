prompt " Get analyzed Details for indexes "
accept owner prompt "Please Enter Owner Name :"
accept table_name prompt "Please Enter table Name:"
set linesize 200
set feedback off
set verify off

column table_owner format a30
column table_name format a30 
column owner format a30 
column index_name format a30

select table_owner,table_name,owner,index_name,partitioned,
       num_rows,to_char(last_analyzed,'DD-MON-YYYY HH24:MI') as last_analyzed,user_stats,temporary,
       sample_size,decode(num_rows, 0, 1, (sample_size/num_rows)*100) est_pct
from dba_indexes
where table_name = upper('&table_name')
and table_owner = upper('&owner')
and index_name = upper('%&index_name%')
; 

column username format A20
column index_name format a20
column partition_name format a10
column object_type format a15
accept index_name prompt "Please Enter Index Name :"
prompt " Get History Index Details "
prompt "***************************************************"
prompt " Last_analyed column means  previous date of current analyze date "
prompt "stats_saved means when Current Analyzed date"
prompt " This history optstat_tab_history shows only last_analyzed records "
prompt " If you want stats_saved which is current analyzed date please run dba_table query"
prompt " If last_analyzed column value is null then probably delete statistics command run"
prompt "***************************************************"

SELECT u.name as  username, o.name as index_name, decode(o.type#, 1, 'INDEX', 20, 'INDEX PARTITION', 35, 'INDEX SUBPARTITION', 'UNDEFINED' ) object_type,
rowcnt num_rows, samplesize, case when rowcnt > 0 then round((samplesize/rowcnt)*100,2) else null end sample_pct, 
blevel, leafcnt leaf_blocks, distkey distinct_keys, lblkkey avg_leaf_blocks_per_key, dblkkey avg_data_blocks_per_key,
clufac clustering_factor, to_char(analyzetime,'DD-MON-YY HH24:MI:SS') last_analyzed, to_char(savtime,'DD-MON-YY HH24:MI:SS') current_analyzed
FROM sys.user$ u, sys.obj$ o, sys.wri$_optstat_ind_history h
where  h.obj# = o.obj# and o.owner# = u.user# 
and u.name = upper('&owner') 
and o.name = upper('&index_name')
order by o.name, analyzetime;

exit;
