col sid for 999999
set linesize 2000
set pagesize 100
col serial# for 999999
col username for a12
col osuser for a12
col event for a30
col program format a30
set head on verify off
select nvl(w.program, nvl(p.program, '<unknown program>')) program, w.process,w.sid,w.serial#, w.osuser, w.username , substr(x.event,1,30) "event",x.p1,x.p2,w.sql_hash_value
from v$session w, v$session_wait x,
     v$process p
where 
w.sid=nvl('&sid',w.sid)
and w.sid = x.sid
and w.paddr = p.addr (+)
and x.event not in ('SQL*Net message from client',
                      'rdbms ipc message',
                      'SQL*Net more data from client',
                      'smon timer',
                      'Null event',
                      'parallel query dequeue wait',
                      'pipe get'
                      ) order by x.event;
exit;
