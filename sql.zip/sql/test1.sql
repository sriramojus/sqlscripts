set trimspool on 
set trim on 
set pages 0 
set linesize 1000 
set long 1000000 
set longchunksize 1000000 
spool sqlmon_active_1st_run.html 
select dbms_sqltune.report_sql_monitor(sql_id=>'&sqlid',type=>'active', report_level=>'ALL') from 
dual; 
spool off 
