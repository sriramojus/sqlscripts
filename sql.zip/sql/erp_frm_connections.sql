set linesize 200
column sid format 9999999999999
column serial# format 999999999
column spid format a10 heading "Database|Process"
column unix_process format a7 heading "Client|Process"
column user_name format a15 trunc heading "FNDUSER|NAME"
column machine format a20 heading "Client|Machine"
column username format a20 heading "Database|Username"

select distinct  u.user_name,s.inst_id,s.sid,s.serial#,p.spid,s.process unix_process,s.machine,
       s.username,to_char(a.start_time ,'DD-MON-YYYY HH24:MI') start_time,s.status
from gv$process p,gv$session s,applsys.fnd_logins a,applsys.fnd_user u 
where p.addr = s.paddr 
and s.process=a.spid 
and p.pid=a.pid 
and a.user_id=u.user_id 
and a.end_time is null
and p.inst_id=s.inst_id
AND SUBSTR(s.status,1,1) LIKE UPPER(NVL('&status_I_A_','%'))
order by 10
/

exit;
