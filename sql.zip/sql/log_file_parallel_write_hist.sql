set linesize 200
set verify off
set feedback off
set pages 99
prompt "*************************************************************************************************************"
prompt " Get log file sync wait event history details from gv table memory where average time_waited > 20 milliseconds"
prompt "*************************************************************************************************************"
prompt  "*************************************************************************************************************"
column program format a30 wrap
column event format a25 wrap

select /*+ parallel (8) */ to_char(sample_time,'DD-MON-YYYY DY HH24:MI') sample_time, inst_id inst, program, event,
sum(time_waited)/1000 TOTAL_WAIT_TIME ,
avg(time_waited)/1000 AVG_TIME_WAITED
from gv$active_session_history
where event='log file parallel write'
group by to_char(sample_time,'DD-MON-YYYY DY HH24:MI'), inst_id, program, event
having avg(time_waited)/1000 > 20
order by 1,2,3,5 desc, 4;

prompt "*************************************************************************************************************"
prompt " Get 7 days old  log file sync wait event history details from DBA hist table memory where average time_waited > 20 milliseconds"
prompt "*************************************************************************************************************"
select /*+ parallel (8) */ to_char(sample_time,'DD-MON-YYYY DY HH24:MI') sample_time, INSTANCE_NUMBER inst, program, event,
sum(time_waited)/1000 TOTAL_WAIT_TIME ,
avg(time_waited)/1000 AVG_TIME_WAITED
from DBA_HIST_ACTIVE_SESS_HISTORY
where event='log file sync'
and   trunc(sample_time) > sysdate -7
group by to_char(sample_time,'DD-MON-YYYY DY HH24:MI'), instance_number, program, event
having avg(time_waited)/1000 > 20
order by 1,2,3,5 desc, 4;

exit;
