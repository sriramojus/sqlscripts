set verify off
set long 100000
set lines 132
set pages 0
prompt 'Pl Enter the Input in Capital Letters............'
accept owner char prompt 'Enter Owner : '
accept object_type char prompt 'Enter Object Type [TABLE/INDEX/MATERIALIZED VIEW/PACKAGE/PROCEDURE/FUNCTION] : '
accept object_name char prompt 'Enter Object Name : '
select dbms_metadata.get_ddl('&&object_type','&&object_name','&&owner') from dual;
exit;
