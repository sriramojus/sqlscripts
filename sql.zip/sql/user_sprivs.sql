--------------------------------------------------------------------------------
-- SCCS INFO : user_sprivs.sql [1.12] 06/25/02 23:34:34
-- FILE INFO : user_sprivs.sql
-- CREATED   : ckarthik
-- DATE      : 07/02/2000
-- DESC      : Displays System privileges grant to User by Direct/Role
--------------------------------------------------------------------------------
CLEAR  COL BREAK COMPUTE
SET    PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF

COLUMN grantee FORMAT A23 HEADING 'USER NAME'
COLUMN abc     FORMAT A27 HEADING 'GRANTED BY?'
COLUMN def     FORMAT A28 HEADING 'PRIVILEGE'

BREAK ON grantee on abc SKIP 1

SELECT sq.grantee, sq.abc, sq.def
FROM  (SELECT DISTINCT b.grantee, 'ROLE '||b.granted_role abc, a.privilege def
       FROM   dba_sys_privs a, dba_role_privs b
       WHERE  a.grantee = b.granted_role
       UNION
       SELECT distinct c.grantee, 'DIRECT' abc, c.privilege def
       FROM   dba_sys_privs c ) sq
WHERE  sq.grantee LIKE UPPER('%&UserName______%')
AND    sq.abc     LIKE UPPER('%&Role__________%')
AND    sq.def     LIKE UPPER('%&Privilege_____%')
ORDER  BY 1, 2
;
SET    PAGES 32 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT
exit;
