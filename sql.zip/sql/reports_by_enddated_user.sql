set lines 120  verify off echo off pages 100;
col user_name format a20
col phase format a20
col status format a20
select /*+parallel(a,8) parallel(b,8)*/a.request_id,
decode(a.PHASE_CODE,'C','Completed','I','Inactive','P','Pending','R','Running') phase,
        decode(a.Status_code,'A','Waiting','B','Resuming','C','Normal','D','Cancelled','E','Error','F',
        'Scheduled','G','Warning','H','On Hold','I','Normal','M','No Manager','Q','Standby','R',
        'Normal','S','Suspended','T','Terminating','U','Disabled','W','Paused','X','Terminated',
        'Z','Waiting') status,
b.user_name,b.end_date
from apps.fnd_concurrent_requests a,apps.fnd_user b
where a.requested_by=b.user_id
and b.end_date < sysdate - 1
and a.phase_code<>'C';
exit;
