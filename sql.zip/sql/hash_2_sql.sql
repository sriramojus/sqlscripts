set pagesize 4000
set long 4000 verify off
select sql_text
from v$sqltext
where
hash_value=nvl('&hash_value',0)
order by piece;
exit;
