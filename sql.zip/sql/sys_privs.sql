set linesize 120

column grantee format a10
column owner format a10
column table_name format a30
column grantor format a10
column grantable format a3


select * from dba_sys_privs
where grantee = '&grantee'
;
exit;
