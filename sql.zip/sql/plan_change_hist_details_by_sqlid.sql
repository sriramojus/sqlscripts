set linesize 200
set pages 99
set verify off
set feedback off

prompt "************************************SAMPLE OUTPUT FOR EACH SQLID *********************************************************"
prompt SNAP_ID        SAMPLE_END	   SQL_ID        PLAN_HASH_VALUE executions VersionCount Invalidation Phy IO/Exec LogIO/Exec Elapsed_Time_In_Sec/Exec CPU_Time_In_Sec/Exec  Rows/Exec
prompt "---------- --------------------- ------------- --------------- ---------- ------------ ------------ ----------- ---------- ------------------------ -------------------- ----------"
prompt" 68514       27-FEB-2014 THU 10:00 6pcs702s69rf7	   123456789	      1	     2		     0	        4759       878569       3.18		         .6	             1"
prompt" 68514       27-FEB-2014 THU 12:00 6pcs702s69rf7	   123765897          1	     1		     0	        3899       719716	2.8	                .56	             1"

prompt               num_days :  how many days old sql's you want to check (default 1 day)
column sample_end format a21

select s.snap_id,to_char(s.begin_interval_time,'DD-MON-YYYY DY HH24:MI') sample_end
, q.sql_id
, q.plan_hash_value
, q.EXECUTIONS_DELTA "executions"
, q.VERSION_COUNT "VersionCount"
, q.INVALIDATIONS_DELTA  "Invalidation"
, round(disk_reads_delta/executions_delta) "Phy IO/Exec"
, round(buffer_gets_delta/executions_delta) "LogIO/Exec"
, round(elapsed_time_delta*0.0000001/executions_delta,2) "Elapsed_Time_In_Sec/Exec"
, round(cpu_time_delta*0.0000001/executions_delta,2) "CPU_Time_In_Sec/Exec"
, round(rows_processed_delta/executions_delta) "Rows/Exec"
from dba_hist_sqlstat q, dba_hist_snapshot s
where q.SQL_ID=trim('&sql_id')
and s.snap_id = q.snap_id
and s.dbid = q.dbid
and s.instance_number = q.instance_number
and q.executions_delta > 0
and begin_interval_time BETWEEN (SYSDATE - nvl(to_number('&num_days'),1)) AND SYSDATE
order by q.sql_id,s.snap_id desc
/

exit;
