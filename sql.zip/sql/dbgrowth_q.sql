set pages 1000 lines 300 feed off
col FISCAL_QTR form a20
select QTR||
case when substr(crdt,1,3)='AUG' or substr(crdt,1,3)='SEP' or substr(crdt,1,3)='OCT'
then to_number(substr(crdt,5,2))+1
when substr(crdt,1,3)='NOV' or substr(crdt,1,3)='DEC' then to_number(substr(crdt,5,2))+1
else to_number(substr(crdt,5,2)) end FISCAL_QTR,sum(GTHINGB) as "GRWTH(in GB)" 
 from
(select to_char(creation_time,'MON-YY') CRDT,
        case when substr(to_char(creation_time,'MON-YY'),1,3)='FEB'
               or substr(to_char(creation_time,'MON-YY'),1,3)='MAR'
               or substr(to_char(creation_time,'MON-YY'),1,3)='APR' then 'Q3FY'
             when substr(to_char(creation_time,'MON-YY'),1,3)='MAY'
               or substr(to_char(creation_time,'MON-YY'),1,3)='JUN'
               or substr(to_char(creation_time,'MON-YY'),1,3)='JUL' then 'Q4FY'
             when substr(to_char(creation_time,'MON-YY'),1,3)='AUG'
               or substr(to_char(creation_time,'MON-YY'),1,3)='SEP'
               or substr(to_char(creation_time,'MON-YY'),1,3)='OCT' then 'Q1FY'
        else 'Q2FY' end QTR,round(sum(bytes)/1024/1024/1024,0) GTHINGB from v$datafile
group by to_char(creation_time,'MON-YY')
)
group by (QTR||case when substr(crdt,1,3)='AUG' or substr(crdt,1,3)='SEP'
         or substr(crdt,1,3)='OCT'
        then to_number(substr(crdt,5,2))+1
                when substr(crdt,1,3)='NOV' or substr(crdt,1,3)='DEC'
        then to_number(substr(crdt,5,2))+1
        else to_number(substr(crdt,5,2)) end )
order by substr(FISCAL_QTR,5,2),substr(FISCAL_QTR,1,2) 
/
exit;
