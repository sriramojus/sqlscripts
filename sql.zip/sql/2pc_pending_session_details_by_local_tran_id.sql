set linesize 200
prompt " Get Session Details from Local transaction ID"
prompt " Let say Local Transaction ID 12.10.351525 "
prompt "xidusn should 12  and xidslot should 10 and xidsqn should 351525 "
prompt " You should get Local Transaction ID informations from alert.log
column sql_id format a20
column osuser format a20 wrap
column username format a20 wrap
column sql_text format a100 wrap
select s.sql_id,s.osuser, s.username,s.inst_id,s.sid,s.serial#,a.sql_text
from gv$transaction t, gv$session s, gv$sqlarea a
where s.taddr = t.addr
and a.address = s.prev_sql_addr
and t.xidusn = &1stnumber
and t.xidslot = &2ndnumber
and t.xidsqn = &3rdnumber
/

exit;
