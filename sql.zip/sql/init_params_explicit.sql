set verify off lines 200 pages 2000
col NAME format a40
col VALUE format a40
select name,value from v$parameter where isdefault='FALSE' and upper(name) like upper('%&param_name%');
exit;
