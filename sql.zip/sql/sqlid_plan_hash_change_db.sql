----------------------------------------------------------------------------------------
--
--  File name:   unstable_plans.sql
--
prompt  Purpose:     Attempts to find SQL statements with plan change based on Execution Time 
prompt How to choose most affected SQLIDs : By comparing sum(execs) , min(Exec_time)  and Max(Exec_time) values with other SQLIDs
prompt Example : SQL_ID        SUM(EXECS)   MIN_ETIME   MAX_ETIME   NORM_STDDEV
prompt "         ------------- ---------- ----------- ----------- -------------"
prompt "        0qa98gcnnza7h         62       25.58      314.34        7.9833"
prompt In this above Example : It has been executed 62 times and one plan averages about 25 seconds while another averages about 314 seconds.
--
-- Author:      Kerry Osborne
--
prompt  Usage:       This scripts prompts for three values, three of which can be left blank.
--
prompt               min_stddev: the minimum "normalized" standard deviation between plans (the default is 2)
--
prompt               min_exec_time:  only include statements that have an avg. exectime > this value   (the default is 1 second)
prompt               num_days :  how many days old sql's you want to check (default 1 day)
-- See http://kerryosborne.oracle-guy.com/2008/10/unstable-plans/ for more info.
---------------------------------------------------------------------------------------
set lines 200
set pages 60
set feedback off
set verify off
col execs for 999,999,999
col min_etime for 999,999.99
col max_etime for 999,999.99
col avg_etime for 999,999.999
col avg_lio for 999,999,999.9
col norm_stddev for 999,999.9999
col begin_interval_time for a30
col node for 9999999999
break on plan_hash_value on startup_time skip 1
select * from (
select sample_end,sql_id, sum(execs), min(avg_etime) min_exectime, max(avg_etime) max_exectime, stddev_etime/min(avg_etime) norm_stddev
from (
select sample_end,sql_id, plan_hash_value, execs, avg_etime,stddev(avg_etime) over (partition by sql_id) stddev_etime
from (
select to_char(ss.begin_interval_time,'DD-MON-YYYY') sample_end,sql_id, plan_hash_value,sum(nvl(executions_delta,0)) execs,
(sum(elapsed_time_delta)/decode(sum(nvl(executions_delta,0)),0,1,sum(executions_delta))/1000000) avg_etime
 from DBA_HIST_SQLSTAT S, DBA_HIST_SNAPSHOT SS, (
    SELECT /*+ NO_MERGE */ MIN(snap_id) min_snap, MAX(snap_id) max_snap
    FROM dba_hist_snapshot sn
    WHERE sn.begin_interval_time BETWEEN (SYSDATE - nvl(to_number('&num_days'),1)) AND SYSDATE
    ) snp
where ss.snap_id = S.snap_id
and s.snap_id BETWEEN snp.min_snap AND snp.max_snap
and ss.instance_number = S.instance_number
and executions_delta > 0
group by to_char(ss.begin_interval_time,'DD-MON-YYYY'),sql_id, plan_hash_value
)
)
group by sample_end,sql_id, stddev_etime
)
where norm_stddev > nvl(to_number('&min_stddev'),2)
and max_exectime > nvl(to_number('&min_exectime'),1)
order by norm_stddev
/

exit;
