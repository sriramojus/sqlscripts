set lines 200 pages 10 verify off

set linesize 200
column tablespace format a20 wrap
PROMPT
PROMPT Temp Tablespace Details
PROMPT
select a.tablespace,b.tot "Total in GB",a.used "Used in GB",trim(ROUND(100-((1-(a.used/b.tot))*100))) used_pct
from
(select s.tablespace,round(sum((s.blocks*p.value)/1024/1024/1024),0) used from gv$sort_usage s, v$parameter p where p.name='db_block_size' group by s.tablespace) a,
(select tablespace_name,round(sum(bytes/1024/1024/1024),0) tot from dba_temp_files group by tablespace_name) b
where a.tablespace=b.tablespace_name
order by 2 desc;

prompt
prompt " ********************************************************************************************"
prompt " GLOBAL TEMP USAGE INSTANCES LEVEL "
prompt " **********************************************************************************************"

SELECT   A.tablespace_name tablespace, D.mb_total, E.Allocated,
SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used,
D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_free
FROM     gv$sort_segment A,
(
SELECT   B.INST_ID,B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
FROM     gv$tablespace B, gv$tempfile C
WHERE    B.ts#= C.ts#
and c.inst_id=b.inst_id
GROUP BY B.INST_ID,B.name, C.block_size
) D,
(
select inst_id, sum(extents_cached) Allocated
from gv$temp_extent_pool
group by inst_id order by 1
) E
WHERE
A.tablespace_name = D.name
and A.inst_id=D.inst_id
and A.inst_id=E.inst_id
and D.inst_id=E.inst_id
GROUP by A.tablespace_name, D.mb_total, E.allocated
order by a.tablespace_name
/

prompt
prompt " ********************************************************************************************"
prompt " TEMP TABLESPACE INFO "
prompt " **********************************************************************************************"

 
SELECT
    d.tablespace_name                      name
  , d.status                               status
  , NVL(a.bytes/1024/1024, 0)              size_mb
  , NVL(t.bytes/1024/1024, 0)              used_mb
  , TRUNC(NVL(t.bytes / a.bytes * 100, 0)) used_pct
  , NVL(s.current_users, 0)                current_users
FROM
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes) bytes
      from dba_temp_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes_used) bytes
      from gv$temp_extent_pool
      group by tablespace_name
    ) t
  , v$sort_segment  s 
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = t.tablespace_name(+)
  AND d.tablespace_name = s.tablespace_name(+)
  AND d.extent_management like 'LOCAL'
  AND d.contents like 'TEMPORARY'
/
exit;
