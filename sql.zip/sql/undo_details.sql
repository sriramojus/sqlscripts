set linesize 200
set pages 99
set verify off
Prompt
Prompt  Global Undo Tablespace Details
Prompt ###############################################
Prompt 
col Undo_Retention format a10
select a.tablespace_name,nvl(a.tot,0) "Total Size in GB",
       nvl(round(b.active,2),0) "Used/Active in GB",
       nvl(round((b.active*100/a.tot),2),0) percent_used,
       nvl(d.unexpired,0) "Unexpired in GB",nvl(c.expired,0) "Expired in GB",f.undo_ret Undo_Retention
from
(select tablespace_name, round(sum(bytes)/(1024*1024*1024),2) tot
  from dba_data_files where tablespace_name in (select value from gv$parameter where name='undo_tablespace')
 group by tablespace_name) a,
(select tablespace_name,round(sum(bytes)/1024/1024/1024,2) active from dba_undo_extents where status='ACTIVE' group by tablespace_name) b,
(select tablespace_name,round(sum(bytes)/1024/1024/1024,2) expired from dba_undo_extents where status='EXPIRED' group by tablespace_name) c,
(select tablespace_name,round(sum(bytes)/1024/1024/1024,2) unexpired from dba_undo_extents where status='UNEXPIRED' group by tablespace_name) d,
(select tablespace_name,ltrim(round(sum(bytes)/1024/1024)) free  from dba_data_files
  where tablespace_name in (select value from gv$parameter where name='undo_tablespace')
 group by tablespace_name) e,
(select y.value tablespace_name,x.value undo_ret from
(select inst_id,value from gv$parameter where name='undo_retention') x,
(select inst_id,value from gv$parameter where name='undo_tablespace') y
where x.inst_id=y.inst_id) f
where a.tablespace_name=b.tablespace_name(+)
and a.tablespace_name=c.tablespace_name(+)
and a.tablespace_name=d.tablespace_name(+)
and a.tablespace_name=e.tablespace_name(+)
and a.tablespace_name=f.tablespace_name(+)
order by 1
;
accept x prompt "Enter for continue ***************************"

Prompt ############################################
Prompt Global  Undo Generated (KB) per second
Prompt ############################################
Prompt
select inst_id,nvl(round((a.blks*b.value)/1024,0),0) "KB per Second"
from
(select inst_id,(sum(undoblks))/sum((end_time-begin_time)*86400) blks from gv$undostat group by inst_id) a,
(select value from v$parameter where name='db_block_size') b
;

prompt " OPTIMAL VALUEs of UNDO SIZE as well as UNDO RETENTION "
prompt " ************************************************************************"
set linesize 200
column tablespace_name format a30

SELECT d.tablespace_name,d.undo_size/(1024*1024) "ACTUAL UNDO SIZE [MByte]",
       to_number(e.value) "UNDO RETENTION [Sec]",
       (TO_NUMBER(e.value) * TO_NUMBER(f.value) * g.undo_block_per_sec) / (1024*1024) "NEEDED UNDO SIZE [MByte]"
  FROM (
       SELECT c.tablespace_name,SUM(a.bytes) undo_size
         FROM v$datafile a,
              v$tablespace b,
              dba_tablespaces c
        WHERE c.contents = 'UNDO'
          AND c.status = 'ONLINE'
          AND b.name = c.tablespace_name
          AND a.ts# = b.ts#
          group by tablespace_name
       ) d,
      v$parameter e,
      v$parameter f,
       (
       SELECT MAX(undoblks/((end_time-begin_time)*3600*24))
         undo_block_per_sec
         FROM v$undostat
        ) g
 WHERE e.name = 'undo_retention'
 AND f.name = 'db_block_size'
/
set linesize 200
column tablespace_name format a30
SELECT d.tablespace_name,d.undo_size/(1024*1024) "ACTUAL UNDO SIZE [MByte]",
    to_number(e.value) "UNDO RETENTION [Sec]",
    ROUND((d.undo_size / (to_number(f.value) * g.undo_block_per_sec))) "OPTIMAL UNDO RETENTION [Sec]"
  FROM (
       SELECT c.tablespace_name,SUM(a.bytes) undo_size
          FROM v$datafile a,
               v$tablespace b,
               dba_tablespaces c
         WHERE c.contents = 'UNDO'
           AND c.status = 'ONLINE'
           AND b.name = c.tablespace_name
           AND a.ts# = b.ts#
           group by c.tablespace_name
       ) d,
       v$parameter e,
       v$parameter f,
       (
       SELECT MAX(undoblks/((end_time-begin_time)*3600*24))undo_block_per_sec
       FROM v$undostat
       ) g
WHERE e.name = 'undo_retention'
  AND f.name = 'db_block_size'
/

accept x prompt "Enter for continue ***************************"
prompt ********************************************************************************************
prompt Displays the UNDO statistics which includes the number of ORA-1555s, the longest query time,
prompt  and (Un)Expired Steals (SC).  The "steal" values are the number of requests for steals, not the actual number of blocks stolen (not reported in this query).
prompt  When the UNExp SC is > 0, that indicates a UNDO space issue.
prompt  MAXCONCURRENCY Identifies the highest number of transactions executed concurrently within the period
prompt TXNCOUNT Identifies the total number of transactions executed within the period
prompt SQL ID SQL identifier of the longest running SQL statement in the period
prompt Identifies the length of the longest query (in seconds) executed in the instance during the period
prompt ********************************************************************************************/
set linesize 200

select inst_id, to_char(begin_time, 'mm/dd/yyyy hh24:mi') "Begin_time",to_char(end_time, 'mm/dd/yyyy hh24:mi') "End Time",
       ssolderrcnt "ORA-1555s", maxquerylen "Longest Query(Sec)",
       unxpstealcnt "UNExp SC", expstealcnt "Exp SC",
       NOSPACEERRCNT "ORA-30036s",MAXQUERYID "SQLID",MAXCONCURRENCY "Max Concurrency Trans",TXNCOUNT "Tot Trans"
  from gv$undostat
where unxpstealcnt > 0
OR    ssolderrcnt > 0
OR    NOSPACEERRCNT > 0
order by inst_id,begin_time
;

exit;
