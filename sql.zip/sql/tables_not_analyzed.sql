set linesize 200
set pages 99
set feedback off
set verify off

prompt "Tables not analyzed in the last 7.5 days but analyzed at least once within the last 60 days"
prompt " ********************************************************************************************"
column owner format a20 wrap

select owner, trunc(last_analyzed), count(*) from dba_tables a 
WHERE a.last_analyzed is not null
and a.last_analyzed between (sysdate - 60)  and (sysdate - 7.5)
group by owner, trunc(last_analyzed)
order by 1, 2
/

accept space prompt " Press Enter for continue :"

prompt "Indexes not analyzed in the last 7.5 days but analyzed at least once within the last 60 days"
prompt "********************************************************************************************"
column owner format a20 wrap

select owner, trunc(last_analyzed), count(*) from dba_indexes a 
WHERE a.last_analyzed is not null
and a.last_analyzed between (sysdate - 60)  and (sysdate - 7.5)
group by owner, trunc(last_analyzed)
order by 1, 2
/

accept space prompt " Press Enter for continue :"

prompt "Tables never analyzed"
prompt "**************************************"
column owner format a20 wrap

select owner, trunc(last_analyzed), count(*) from dba_tables a 
WHERE a.last_analyzed is null
group by owner, trunc(last_analyzed)
order by 1, 2
/

accept space prompt " Press Enter for continue :"

prompt "Indexes never analyzed"
prompt "****************************************************"
column owner format a20 wrap
select owner, trunc(last_analyzed), count(*) from dba_indexes a 
WHERE a.last_analyzed is null
group by owner, trunc(last_analyzed)
order by 1, 2
/


accept space prompt " Press Enter for continue :"
prompt "Partitioned Tables not analyzed in the last 7.5 days but analyzed at least once within the last 60 days"
prompt "*********************************************************************************************************"

select table_owner, trunc(last_analyzed), count(*) from dba_tab_partitions a 
WHERE a.last_analyzed is not null
and a.last_analyzed between (sysdate - 60)  and (sysdate - 7.5)
group by table_owner, trunc(last_analyzed)
order by 1, 2
/

accept space prompt " Press Enter for continue :"
prompt "Partitioned Indexes  not analyzed in the last 7.5 days but analyzed at least once within the last 60 days"
prompt "*********************************************************************************************************"

select index_owner, trunc(last_analyzed), count(*) from dba_ind_partitions a 
WHERE a.last_analyzed is not null
and a.last_analyzed between (sysdate - 60)  and (sysdate - 7.5)
group by index_owner, trunc(last_analyzed)
order by 1, 2
/

accept space prompt " Press Enter for continue :"
prompt "Partitioned Tables never analyzed"
prompt "********************************************"
select table_owner, trunc(last_analyzed), count(*) from dba_tab_partitions a 
WHERE a.last_analyzed is null
group by table_owner, trunc(last_analyzed)
order by 1, 2
/

accept space prompt " Press Enter for continue :"
prompt "Partitioned Indexes never analyzed"
prompt "********************************************"

select index_owner, trunc(last_analyzed), count(*) from dba_ind_partitions a 
WHERE a.last_analyzed is null
group by index_owner, trunc(last_analyzed)
order by 1, 2
/

exit;
