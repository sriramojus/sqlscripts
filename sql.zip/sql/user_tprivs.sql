--------------------------------------------------------------------------------
-- SCCS INFO : user_tprivs.sql [1.3] 06/25/02 23:34:34
-- FILE INFO : user_tprivs.sql
-- CREATED   : ckarthik
-- DATE      : 07/02/2000
-- DESC      : Displays Sess info with SQL-TEXT.
--------------------------------------------------------------------------------
CLEAR  COL BREAK COMPUTE
SET    PAGES 100 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF

COL grantee   FORMAT A10
COL tbl       FORMAT A40
COL grantor   FORMAT A10
COL privilege FORMAT A10
COL grt       FORMAT A3

SELECT grantor, owner||'.'||table_name tbl, privilege, grantee, grantable grt
FROM   dba_tab_privs
WHERE  grantee    LIKE UPPER('%&grantee_______%')
AND    grantor    LIKE UPPER('%&grantor_______%')
AND    table_name LIKE UPPER('%&table_name____%')
AND    privilege  LIKE UPPER('%&privilege_____%')
ORDER  BY grantee, grantor, owner,privilege, table_name
;

SET    PAGES 32 PAUSE OFF VERIFY OFF FEEDBACK ON ECHO OFF
PROMPT
exit;
