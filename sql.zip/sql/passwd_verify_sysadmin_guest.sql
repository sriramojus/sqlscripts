set linesize 200
column user_name format a30 wrap
column description format a30 wrap
column ENCRYPTED_USER_PASSWORD format a50 wrap
select user_name ,description , ENCRYPTED_USER_PASSWORD "ENCRYPTED PASSWORD", PASSWORD_DATE "PASSWORD CHANGED DATE",to_char(end_date,'DD-MON-YYYY') as End_Date 
from apps.fnd_user 
where user_name in ('SYSADMIN','GUEST');

exit;
