set linesize 200
set pages 99

prompt "view of all Concurrent Requests that are currently Pending sorted by status code"
column status format a30
SELECT 'Pending' pphase, meaning status, count(*) numreqs
FROM apps.fnd_concurrent_requests, apps.fnd_lookups
WHERE LOOKUP_TYPE = 'CP_STATUS_CODE' AND lookup_code = status_code AND phase_code = 'P'
GROUP BY meaning;

prompt "displays a count all pending Concurrent requests that are Regularly Scheduled and those pending requests which are not Regularly scheduled"
accept space prompt "Press Enter for Continue ********************"

select 'Pending Regularly Scheduled requests:' schedt, count(*) schedcnt
from apps.fnd_concurrent_requests
WHERE (requested_start_date > sysdate OR status_code = 'P') AND phase_code = 'P';

select 'Pending Non Regularly Scheduled requests:' schedt, count(*) schedcnt
from apps.fnd_concurrent_requests
WHERE requested_start_date <= sysdate AND status_code != 'P' AND phase_code = 'P';

prompt "count of the Total Pending Requests that are currently on Hold and those pending requests not on Hold"
accept space prompt "Press Enter for Continue ********************"

select 'Pending Requests on hold:' schedt, count(*) schedcnt
from apps.fnd_concurrent_requests
WHERE hold_flag = 'Y' AND phase_code = 'P';


select 'Pending Requests Not on hold:' schedt, count(*) schedcnt
from apps.fnd_concurrent_requests
WHERE hold_flag != 'Y' AND phase_code = 'P';

prompt "A Count listing of All Pending Requests Currently on Hold and wating to be run "
accept space prompt "Press Enter for Continue ********************"

column pname format a50

SELECT request_id id, nvl(meaning, 'UNKNOWN') status, user_concurrent_program_name pname,
to_char(request_date, 'DD-MON-RR HH24:MI:SS') submitd
FROM apps.fnd_concurrent_requests fcr, apps.fnd_lookups fl, apps.fnd_concurrent_programs_vl fcpv
WHERE phase_code = 'P' AND hold_flag = 'Y' AND fcr.requested_start_date <= sysdate
AND status_code != 'P' AND LOOKUP_TYPE = 'CP_STATUS_CODE' AND lookup_code = status_code
AND fcr.concurrent_program_id = fcpv.concurrent_program_id AND fcr.program_application_id = fcpv.application_id
ORDER BY request_date, request_id;

exit;
