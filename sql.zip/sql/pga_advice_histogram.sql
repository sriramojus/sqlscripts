set pagesize 1000
set lines 200
column name format a22
column description format a40
column MB format 99,999

connect / as sysdba;

SELECT ksppinm name, ksppdesc description,
       CASE WHEN ksppinm LIKE '_smm%' THEN ksppstvl/1024 
             ELSE ksppstvl/1048576 END as MB
  FROM sys.x$ksppi JOIN sys.x$ksppcv
       USING (indx)
WHERE ksppinm IN
            ('pga_aggregate_target',
             '_pga_max_size',
             '_smm_max_size',
             '_smm_px_max_size','__pga_aggregate_target' 
              ); 

connect / as sysdba

set pages 100
set lines 200
set echo on
column size_mb format 99,99,99,99,999 heading "Size|MB"
column estd_target_pct format 9,999 heading "Rel|Size %"
column extra_bytes_histogram format a60 heading "Relative Extra Bytes RW"

SELECT inst_id,ROUND(PGA_TARGET_FOR_ESTIMATE / 1048576) size_mb,
       ROUND(PGA_TARGET_FACTOR * 100, 2) estd_target_pct,
       RPAD(' ',
       ROUND(ESTD_EXTRA_BYTES_RW / MAX(ESTD_EXTRA_BYTES_RW) OVER () * 60),
       DECODE(PGA_TARGET_FACTOR,
              1, '=',
              DECODE(SIGN(estd_overalloc_count), 1, 'x', '*')))
          extra_bytes_histogram
FROM gv$pga_target_advice
where inst_id like nvl('&inst_id','%')
ORDER BY 1,2 DESC;

exit;
